## [5.1.108](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.107...v5.1.108) (2024-04-05)

## [5.1.107](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.106...v5.1.107) (2024-04-04)

## [5.1.106](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.105...v5.1.106) (2024-04-04)

## [5.1.105](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.104...v5.1.105) (2024-04-04)

## [5.1.104](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.103...v5.1.104) (2024-04-03)

## [5.1.103](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.102...v5.1.103) (2024-04-01)

## [5.1.102](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.101...v5.1.102) (2024-04-01)

## [5.1.101](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.100...v5.1.101) (2024-03-31)

## [5.1.100](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.99...v5.1.100) (2024-03-31)

## [5.1.99](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.98...v5.1.99) (2024-03-30)

## [5.1.98](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.97...v5.1.98) (2024-03-30)

## [5.1.97](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.96...v5.1.97) (2024-03-30)

## [5.1.96](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.95...v5.1.96) (2024-03-30)

## [5.1.95](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.94...v5.1.95) (2024-03-29)

## [5.1.94](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.93...v5.1.94) (2024-03-29)

## [5.1.93](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.92...v5.1.93) (2024-03-29)

## [5.1.92](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.91...v5.1.92) (2024-03-28)

## [5.1.91](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.90...v5.1.91) (2024-03-28)

## [5.1.90](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.89...v5.1.90) (2024-03-28)

## [5.1.89](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.88...v5.1.89) (2024-03-28)

## [5.1.88](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.87...v5.1.88) (2024-03-27)

## [5.1.87](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.86...v5.1.87) (2024-03-27)

## [5.1.86](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.85...v5.1.86) (2024-03-27)

## [5.1.85](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.84...v5.1.85) (2024-03-27)

## [5.1.84](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.83...v5.1.84) (2024-03-26)

## [5.1.83](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.82...v5.1.83) (2024-03-25)

## [5.1.82](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.81...v5.1.82) (2024-03-21)

## [5.1.81](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.80...v5.1.81) (2024-03-21)

## [5.1.80](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.79...v5.1.80) (2024-03-20)

## [5.1.79](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.78...v5.1.79) (2024-03-19)

## [5.1.78](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.77...v5.1.78) (2024-03-19)

## [5.1.77](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.76...v5.1.77) (2024-03-18)

## [5.1.76](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.75...v5.1.76) (2024-03-15)

## [5.1.75](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.74...v5.1.75) (2024-03-13)

## [5.1.74](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.73...v5.1.74) (2024-03-12)

## [5.1.73](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.72...v5.1.73) (2024-03-12)

## [5.1.72](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.71...v5.1.72) (2024-03-12)

## [5.1.71](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.70...v5.1.71) (2024-03-12)

## [5.1.70](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.69...v5.1.70) (2024-03-10)

## [5.1.69](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.68...v5.1.69) (2024-03-10)

## [5.1.68](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.67...v5.1.68) (2024-03-10)

## [5.1.67](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.66...v5.1.67) (2024-03-10)

## [5.1.66](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.65...v5.1.66) (2024-03-06)

## [5.1.65](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.64...v5.1.65) (2024-02-23)

## [5.1.64](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.63...v5.1.64) (2024-02-12)

## [5.1.63](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.62...v5.1.63) (2024-02-04)

## [5.1.62](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.61...v5.1.62) (2024-01-17)

## [5.1.61](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.60...v5.1.61) (2024-01-17)

## [5.1.60](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.59...v5.1.60) (2024-01-14)

## [5.1.59](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.58...v5.1.59) (2024-01-12)

## [5.1.58](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.57...v5.1.58) (2024-01-12)

## [5.1.57](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.56...v5.1.57) (2023-12-16)

## [5.1.56](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.55...v5.1.56) (2023-12-15)

## [5.1.55](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.54...v5.1.55) (2023-12-14)

## [5.1.54](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.53...v5.1.54) (2023-12-13)

## [5.1.53](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.52...v5.1.53) (2023-12-10)

## [5.1.52](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.51...v5.1.52) (2023-12-06)

## [5.1.51](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.50...v5.1.51) (2023-12-06)

## [5.1.50](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.49...v5.1.50) (2023-12-05)

## [5.1.49](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.48...v5.1.49) (2023-11-22)

## [5.1.48](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.47...v5.1.48) (2023-11-21)

## [5.1.47](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.46...v5.1.47) (2023-11-20)

## [5.1.46](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.45...v5.1.46) (2023-11-18)

## [5.1.45](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.44...v5.1.45) (2023-11-14)

## [5.1.44](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.43...v5.1.44) (2023-11-13)

## [5.1.43](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.42...v5.1.43) (2023-11-09)

## [5.1.42](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.41...v5.1.42) (2023-11-07)

## [5.1.41](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.40...v5.1.41) (2023-11-07)

## [5.1.40](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.39...v5.1.40) (2023-11-04)

## [5.1.39](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.38...v5.1.39) (2023-11-04)

## [5.1.38](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.37...v5.1.38) (2023-10-31)

## [5.1.37](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.36...v5.1.37) (2023-10-20)

## [5.1.36](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.35...v5.1.36) (2023-10-19)

## [5.1.35](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.34...v5.1.35) (2023-10-18)

## [5.1.34](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.33...v5.1.34) (2023-10-18)

## [5.1.33](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.32...v5.1.33) (2023-10-18)

## [5.1.32](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.31...v5.1.32) (2023-10-14)

## [5.1.31](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.30...v5.1.31) (2023-09-22)

## [5.1.30](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.29...v5.1.30) (2023-09-16)

## [5.1.29](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.28...v5.1.29) (2023-09-12)

## [5.1.28](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.27...v5.1.28) (2023-09-08)

## [5.1.27](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.26...v5.1.27) (2023-09-06)

## [5.1.26](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.25...v5.1.26) (2023-08-30)

## [5.1.25](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.24...v5.1.25) (2023-08-24)

## [5.1.24](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.23...v5.1.24) (2023-08-22)

## [5.1.23](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.22...v5.1.23) (2023-08-22)

## [5.1.22](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.21...v5.1.22) (2023-08-21)

## [5.1.21](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.20...v5.1.21) (2023-08-11)

## [5.1.20](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.19...v5.1.20) (2023-08-09)

## [5.1.19](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.18...v5.1.19) (2023-07-28)

## [5.1.18](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.17...v5.1.18) (2023-07-27)

## [5.1.17](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.16...v5.1.17) (2023-07-26)

## [5.1.16](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.15...v5.1.16) (2023-07-14)

## [5.1.15](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.14...v5.1.15) (2023-07-10)

## [5.1.14](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.13...v5.1.14) (2023-07-07)

## [5.1.13](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.12...v5.1.13) (2023-07-07)

## [5.1.12](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.11...v5.1.12) (2023-07-07)

## [5.1.11](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.10...v5.1.11) (2023-06-17)

## [5.1.10](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.9...v5.1.10) (2023-06-16)

## [5.1.9](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.8...v5.1.9) (2023-06-09)

## [5.1.8](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.7...v5.1.8) (2023-06-03)

## [5.1.7](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.6...v5.1.7) (2023-06-01)

## [5.1.6](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.5...v5.1.6) (2023-06-01)

## [5.1.5](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.4...v5.1.5) (2023-05-31)

## [5.1.4](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.3...v5.1.4) (2023-05-25)

## [5.1.3](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.2...v5.1.3) (2023-05-19)

## [5.1.2](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.1...v5.1.2) (2023-05-13)

## [5.1.1](https://github.com/sprucelabsai-community/spruce-error/compare/v5.1.0...v5.1.1) (2023-05-11)

# [5.1.0](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.608...v5.1.0) (2023-05-11)


### Features

* errors now print their options in the stack! ([e452813](https://github.com/sprucelabsai-community/spruce-error/commit/e452813))

## [5.0.608](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.607...v5.0.608) (2023-05-05)

## [5.0.607](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.606...v5.0.607) (2023-05-01)

## [5.0.606](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.605...v5.0.606) (2023-04-28)

## [5.0.605](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.604...v5.0.605) (2023-04-27)

## [5.0.604](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.603...v5.0.604) (2023-04-24)

## [5.0.603](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.602...v5.0.603) (2023-04-22)

## [5.0.602](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.601...v5.0.602) (2023-04-19)

## [5.0.601](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.600...v5.0.601) (2023-04-14)

## [5.0.600](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.599...v5.0.600) (2023-04-14)

## [5.0.599](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.598...v5.0.599) (2023-04-11)

## [5.0.598](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.597...v5.0.598) (2023-03-30)

## [5.0.597](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.596...v5.0.597) (2023-03-30)

## [5.0.596](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.595...v5.0.596) (2023-03-29)

## [5.0.595](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.594...v5.0.595) (2023-03-27)

## [5.0.594](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.593...v5.0.594) (2023-03-26)

## [5.0.593](https://github.com/sprucelabsai-community/spruce-error/compare/v5.0.592...v5.0.593) (2023-03-23)

## [5.0.592](https://github.com/sprucelabsai/spruce-error/compare/v5.0.591...v5.0.592) (2023-03-20)

## [5.0.591](https://github.com/sprucelabsai/spruce-error/compare/v5.0.590...v5.0.591) (2023-03-16)

## [5.0.590](https://github.com/sprucelabsai/spruce-error/compare/v5.0.589...v5.0.590) (2023-03-15)

## [5.0.589](https://github.com/sprucelabsai/spruce-error/compare/v5.0.588...v5.0.589) (2023-03-15)

## [5.0.588](https://github.com/sprucelabsai/spruce-error/compare/v5.0.587...v5.0.588) (2023-03-15)

## [5.0.587](https://github.com/sprucelabsai/spruce-error/compare/v5.0.586...v5.0.587) (2023-03-13)

## [5.0.586](https://github.com/sprucelabsai/spruce-error/compare/v5.0.585...v5.0.586) (2023-03-10)

## [5.0.585](https://github.com/sprucelabsai/spruce-error/compare/v5.0.584...v5.0.585) (2023-03-06)

## [5.0.584](https://github.com/sprucelabsai/spruce-error/compare/v5.0.583...v5.0.584) (2023-03-05)

## [5.0.583](https://github.com/sprucelabsai/spruce-error/compare/v5.0.582...v5.0.583) (2023-02-26)

## [5.0.582](https://github.com/sprucelabsai/spruce-error/compare/v5.0.581...v5.0.582) (2023-02-26)

## [5.0.581](https://github.com/sprucelabsai/spruce-error/compare/v5.0.580...v5.0.581) (2023-02-25)

## [5.0.580](https://github.com/sprucelabsai/spruce-error/compare/v5.0.579...v5.0.580) (2023-02-15)

## [5.0.579](https://github.com/sprucelabsai/spruce-error/compare/v5.0.578...v5.0.579) (2023-02-13)

## [5.0.578](https://github.com/sprucelabsai/spruce-error/compare/v5.0.577...v5.0.578) (2023-02-08)

## [5.0.577](https://github.com/sprucelabsai/spruce-error/compare/v5.0.576...v5.0.577) (2023-02-07)

## [5.0.576](https://github.com/sprucelabsai/spruce-error/compare/v5.0.575...v5.0.576) (2023-02-03)

## [5.0.575](https://github.com/sprucelabsai/spruce-error/compare/v5.0.574...v5.0.575) (2023-02-02)

## [5.0.574](https://github.com/sprucelabsai/spruce-error/compare/v5.0.573...v5.0.574) (2023-01-29)

## [5.0.573](https://github.com/sprucelabsai/spruce-error/compare/v5.0.572...v5.0.573) (2023-01-26)

## [5.0.572](https://github.com/sprucelabsai/spruce-error/compare/v5.0.571...v5.0.572) (2023-01-25)

## [5.0.571](https://github.com/sprucelabsai/spruce-error/compare/v5.0.570...v5.0.571) (2023-01-24)

## [5.0.570](https://github.com/sprucelabsai/spruce-error/compare/v5.0.569...v5.0.570) (2023-01-18)

## [5.0.569](https://github.com/sprucelabsai/spruce-error/compare/v5.0.568...v5.0.569) (2023-01-15)

## [5.0.568](https://github.com/sprucelabsai/spruce-error/compare/v5.0.567...v5.0.568) (2023-01-15)

## [5.0.567](https://github.com/sprucelabsai/spruce-error/compare/v5.0.566...v5.0.567) (2023-01-15)

## [5.0.566](https://github.com/sprucelabsai/spruce-error/compare/v5.0.565...v5.0.566) (2023-01-14)

## [5.0.565](https://github.com/sprucelabsai/spruce-error/compare/v5.0.564...v5.0.565) (2023-01-14)

## [5.0.564](https://github.com/sprucelabsai/spruce-error/compare/v5.0.563...v5.0.564) (2023-01-12)

## [5.0.563](https://github.com/sprucelabsai/spruce-error/compare/v5.0.562...v5.0.563) (2023-01-12)

## [5.0.562](https://github.com/sprucelabsai/spruce-error/compare/v5.0.561...v5.0.562) (2023-01-07)

## [5.0.561](https://github.com/sprucelabsai/spruce-error/compare/v5.0.560...v5.0.561) (2023-01-07)

## [5.0.560](https://github.com/sprucelabsai/spruce-error/compare/v5.0.559...v5.0.560) (2023-01-06)

## [5.0.559](https://github.com/sprucelabsai/spruce-error/compare/v5.0.558...v5.0.559) (2023-01-03)

## [5.0.558](https://github.com/sprucelabsai/spruce-error/compare/v5.0.557...v5.0.558) (2022-12-31)

## [5.0.557](https://github.com/sprucelabsai/spruce-error/compare/v5.0.556...v5.0.557) (2022-12-30)

## [5.0.556](https://github.com/sprucelabsai/spruce-error/compare/v5.0.555...v5.0.556) (2022-12-20)

## [5.0.555](https://github.com/sprucelabsai/spruce-error/compare/v5.0.554...v5.0.555) (2022-12-17)

## [5.0.554](https://github.com/sprucelabsai/spruce-error/compare/v5.0.553...v5.0.554) (2022-12-09)

## [5.0.553](https://github.com/sprucelabsai/spruce-error/compare/v5.0.552...v5.0.553) (2022-12-08)

## [5.0.552](https://github.com/sprucelabsai/spruce-error/compare/v5.0.551...v5.0.552) (2022-12-08)

## [5.0.551](https://github.com/sprucelabsai/spruce-error/compare/v5.0.550...v5.0.551) (2022-12-08)

## [5.0.550](https://github.com/sprucelabsai/spruce-error/compare/v5.0.549...v5.0.550) (2022-12-07)

## [5.0.549](https://github.com/sprucelabsai/spruce-error/compare/v5.0.548...v5.0.549) (2022-12-05)

## [5.0.548](https://github.com/sprucelabsai/spruce-error/compare/v5.0.547...v5.0.548) (2022-12-02)

## [5.0.547](https://github.com/sprucelabsai/spruce-error/compare/v5.0.546...v5.0.547) (2022-11-30)

## [5.0.546](https://github.com/sprucelabsai/spruce-error/compare/v5.0.545...v5.0.546) (2022-11-30)

## [5.0.545](https://github.com/sprucelabsai/spruce-error/compare/v5.0.544...v5.0.545) (2022-11-23)

## [5.0.544](https://github.com/sprucelabsai/spruce-error/compare/v5.0.543...v5.0.544) (2022-11-23)

## [5.0.543](https://github.com/sprucelabsai/spruce-error/compare/v5.0.542...v5.0.543) (2022-11-20)

## [5.0.542](https://github.com/sprucelabsai/spruce-error/compare/v5.0.541...v5.0.542) (2022-11-18)

## [5.0.541](https://github.com/sprucelabsai/spruce-error/compare/v5.0.540...v5.0.541) (2022-11-15)

## [5.0.540](https://github.com/sprucelabsai/spruce-error/compare/v5.0.539...v5.0.540) (2022-11-15)

## [5.0.539](https://github.com/sprucelabsai/spruce-error/compare/v5.0.538...v5.0.539) (2022-11-14)

## [5.0.538](https://github.com/sprucelabsai/spruce-error/compare/v5.0.537...v5.0.538) (2022-11-08)

## [5.0.537](https://github.com/sprucelabsai/spruce-error/compare/v5.0.536...v5.0.537) (2022-11-07)

## [5.0.536](https://github.com/sprucelabsai/spruce-error/compare/v5.0.535...v5.0.536) (2022-11-06)

## [5.0.535](https://github.com/sprucelabsai/spruce-error/compare/v5.0.534...v5.0.535) (2022-11-05)

## [5.0.534](https://github.com/sprucelabsai/spruce-error/compare/v5.0.533...v5.0.534) (2022-11-05)

## [5.0.533](https://github.com/sprucelabsai/spruce-error/compare/v5.0.532...v5.0.533) (2022-11-04)

## [5.0.532](https://github.com/sprucelabsai/spruce-error/compare/v5.0.531...v5.0.532) (2022-11-02)

## [5.0.531](https://github.com/sprucelabsai/spruce-error/compare/v5.0.530...v5.0.531) (2022-11-01)

## [5.0.530](https://github.com/sprucelabsai/spruce-error/compare/v5.0.529...v5.0.530) (2022-10-24)

## [5.0.529](https://github.com/sprucelabsai/spruce-error/compare/v5.0.528...v5.0.529) (2022-10-24)

## [5.0.528](https://github.com/sprucelabsai/spruce-error/compare/v5.0.527...v5.0.528) (2022-10-22)

## [5.0.527](https://github.com/sprucelabsai/spruce-error/compare/v5.0.526...v5.0.527) (2022-10-21)

## [5.0.526](https://github.com/sprucelabsai/spruce-error/compare/v5.0.525...v5.0.526) (2022-10-18)

## [5.0.525](https://github.com/sprucelabsai/spruce-error/compare/v5.0.524...v5.0.525) (2022-10-18)

## [5.0.524](https://github.com/sprucelabsai/spruce-error/compare/v5.0.523...v5.0.524) (2022-10-14)

## [5.0.523](https://github.com/sprucelabsai/spruce-error/compare/v5.0.522...v5.0.523) (2022-10-07)

## [5.0.522](https://github.com/sprucelabsai/spruce-error/compare/v5.0.521...v5.0.522) (2022-10-06)

## [5.0.521](https://github.com/sprucelabsai/spruce-error/compare/v5.0.520...v5.0.521) (2022-09-30)

## [5.0.520](https://github.com/sprucelabsai/spruce-error/compare/v5.0.519...v5.0.520) (2022-09-30)

## [5.0.519](https://github.com/sprucelabsai/spruce-error/compare/v5.0.518...v5.0.519) (2022-09-29)

## [5.0.518](https://github.com/sprucelabsai/spruce-error/compare/v5.0.517...v5.0.518) (2022-09-28)

## [5.0.517](https://github.com/sprucelabsai/spruce-error/compare/v5.0.516...v5.0.517) (2022-09-28)

## [5.0.516](https://github.com/sprucelabsai/spruce-error/compare/v5.0.515...v5.0.516) (2022-09-27)

## [5.0.515](https://github.com/sprucelabsai/spruce-error/compare/v5.0.514...v5.0.515) (2022-09-24)

## [5.0.514](https://github.com/sprucelabsai/spruce-error/compare/v5.0.513...v5.0.514) (2022-09-15)

## [5.0.513](https://github.com/sprucelabsai/spruce-error/compare/v5.0.512...v5.0.513) (2022-09-13)

## [5.0.512](https://github.com/sprucelabsai/spruce-error/compare/v5.0.511...v5.0.512) (2022-09-12)

## [5.0.511](https://github.com/sprucelabsai/spruce-error/compare/v5.0.510...v5.0.511) (2022-09-12)

## [5.0.510](https://github.com/sprucelabsai/spruce-error/compare/v5.0.509...v5.0.510) (2022-09-12)

## [5.0.509](https://github.com/sprucelabsai/spruce-error/compare/v5.0.508...v5.0.509) (2022-09-11)

## [5.0.508](https://github.com/sprucelabsai/spruce-error/compare/v5.0.507...v5.0.508) (2022-09-11)

## [5.0.507](https://github.com/sprucelabsai/spruce-error/compare/v5.0.506...v5.0.507) (2022-09-10)

## [5.0.506](https://github.com/sprucelabsai/spruce-error/compare/v5.0.505...v5.0.506) (2022-09-08)

## [5.0.505](https://github.com/sprucelabsai/spruce-error/compare/v5.0.504...v5.0.505) (2022-09-07)

## [5.0.504](https://github.com/sprucelabsai/spruce-error/compare/v5.0.503...v5.0.504) (2022-09-03)

## [5.0.503](https://github.com/sprucelabsai/spruce-error/compare/v5.0.502...v5.0.503) (2022-09-01)

## [5.0.502](https://github.com/sprucelabsai/spruce-error/compare/v5.0.501...v5.0.502) (2022-08-29)

## [5.0.501](https://github.com/sprucelabsai/spruce-error/compare/v5.0.500...v5.0.501) (2022-08-29)

## [5.0.500](https://github.com/sprucelabsai/spruce-error/compare/v5.0.499...v5.0.500) (2022-08-27)

## [5.0.499](https://github.com/sprucelabsai/spruce-error/compare/v5.0.498...v5.0.499) (2022-08-26)

## [5.0.498](https://github.com/sprucelabsai/spruce-error/compare/v5.0.497...v5.0.498) (2022-08-26)

## [5.0.497](https://github.com/sprucelabsai/spruce-error/compare/v5.0.496...v5.0.497) (2022-08-25)

## [5.0.496](https://github.com/sprucelabsai/spruce-error/compare/v5.0.495...v5.0.496) (2022-08-24)

## [5.0.495](https://github.com/sprucelabsai/spruce-error/compare/v5.0.494...v5.0.495) (2022-08-19)

## [5.0.494](https://github.com/sprucelabsai/spruce-error/compare/v5.0.493...v5.0.494) (2022-08-16)

## [5.0.493](https://github.com/sprucelabsai/spruce-error/compare/v5.0.492...v5.0.493) (2022-08-15)

## [5.0.492](https://github.com/sprucelabsai/spruce-error/compare/v5.0.491...v5.0.492) (2022-08-14)

## [5.0.491](https://github.com/sprucelabsai/spruce-error/compare/v5.0.490...v5.0.491) (2022-08-06)

## [5.0.490](https://github.com/sprucelabsai/spruce-error/compare/v5.0.489...v5.0.490) (2022-08-01)

## [5.0.489](https://github.com/sprucelabsai/spruce-error/compare/v5.0.488...v5.0.489) (2022-08-01)

## [5.0.488](https://github.com/sprucelabsai/spruce-error/compare/v5.0.487...v5.0.488) (2022-07-28)

## [5.0.487](https://github.com/sprucelabsai/spruce-error/compare/v5.0.486...v5.0.487) (2022-07-19)

## [5.0.486](https://github.com/sprucelabsai/spruce-error/compare/v5.0.485...v5.0.486) (2022-07-16)

## [5.0.485](https://github.com/sprucelabsai/spruce-error/compare/v5.0.484...v5.0.485) (2022-07-16)

## [5.0.484](https://github.com/sprucelabsai/spruce-error/compare/v5.0.483...v5.0.484) (2022-07-13)

## [5.0.483](https://github.com/sprucelabsai/spruce-error/compare/v5.0.482...v5.0.483) (2022-07-13)

## [5.0.482](https://github.com/sprucelabsai/spruce-error/compare/v5.0.481...v5.0.482) (2022-07-13)

## [5.0.481](https://github.com/sprucelabsai/spruce-error/compare/v5.0.480...v5.0.481) (2022-07-02)

## [5.0.480](https://github.com/sprucelabsai/spruce-error/compare/v5.0.479...v5.0.480) (2022-07-02)

## [5.0.479](https://github.com/sprucelabsai/spruce-error/compare/v5.0.478...v5.0.479) (2022-06-30)

## [5.0.478](https://github.com/sprucelabsai/spruce-error/compare/v5.0.477...v5.0.478) (2022-06-29)

## [5.0.477](https://github.com/sprucelabsai/spruce-error/compare/v5.0.476...v5.0.477) (2022-06-21)

## [5.0.476](https://github.com/sprucelabsai/spruce-error/compare/v5.0.475...v5.0.476) (2022-06-21)

## [5.0.475](https://github.com/sprucelabsai/spruce-error/compare/v5.0.474...v5.0.475) (2022-06-18)

## [5.0.474](https://github.com/sprucelabsai/spruce-error/compare/v5.0.473...v5.0.474) (2022-06-17)

## [5.0.473](https://github.com/sprucelabsai/spruce-error/compare/v5.0.472...v5.0.473) (2022-06-17)

## [5.0.472](https://github.com/sprucelabsai/spruce-error/compare/v5.0.471...v5.0.472) (2022-06-17)

## [5.0.471](https://github.com/sprucelabsai/spruce-error/compare/v5.0.470...v5.0.471) (2022-06-16)

## [5.0.470](https://github.com/sprucelabsai/spruce-error/compare/v5.0.469...v5.0.470) (2022-06-14)

## [5.0.469](https://github.com/sprucelabsai/spruce-error/compare/v5.0.468...v5.0.469) (2022-06-14)

## [5.0.468](https://github.com/sprucelabsai/spruce-error/compare/v5.0.467...v5.0.468) (2022-06-14)

## [5.0.467](https://github.com/sprucelabsai/spruce-error/compare/v5.0.466...v5.0.467) (2022-06-07)

## [5.0.466](https://github.com/sprucelabsai/spruce-error/compare/v5.0.465...v5.0.466) (2022-06-05)

## [5.0.465](https://github.com/sprucelabsai/spruce-error/compare/v5.0.464...v5.0.465) (2022-06-04)

## [5.0.464](https://github.com/sprucelabsai/spruce-error/compare/v5.0.463...v5.0.464) (2022-06-03)

## [5.0.463](https://github.com/sprucelabsai/spruce-error/compare/v5.0.462...v5.0.463) (2022-06-03)

## [5.0.462](https://github.com/sprucelabsai/spruce-error/compare/v5.0.461...v5.0.462) (2022-06-02)

## [5.0.461](https://github.com/sprucelabsai/spruce-error/compare/v5.0.460...v5.0.461) (2022-06-01)

## [5.0.460](https://github.com/sprucelabsai/spruce-error/compare/v5.0.459...v5.0.460) (2022-05-24)

## [5.0.459](https://github.com/sprucelabsai/spruce-error/compare/v5.0.458...v5.0.459) (2022-05-23)

## [5.0.458](https://github.com/sprucelabsai/spruce-error/compare/v5.0.457...v5.0.458) (2022-05-22)

## [5.0.457](https://github.com/sprucelabsai/spruce-error/compare/v5.0.456...v5.0.457) (2022-05-21)

## [5.0.456](https://github.com/sprucelabsai/spruce-error/compare/v5.0.455...v5.0.456) (2022-05-17)

## [5.0.455](https://github.com/sprucelabsai/spruce-error/compare/v5.0.454...v5.0.455) (2022-05-17)

## [5.0.454](https://github.com/sprucelabsai/spruce-error/compare/v5.0.453...v5.0.454) (2022-05-15)

## [5.0.453](https://github.com/sprucelabsai/spruce-error/compare/v5.0.452...v5.0.453) (2022-05-12)

## [5.0.452](https://github.com/sprucelabsai/spruce-error/compare/v5.0.451...v5.0.452) (2022-05-06)

## [5.0.451](https://github.com/sprucelabsai/spruce-error/compare/v5.0.450...v5.0.451) (2022-05-06)

## [5.0.450](https://github.com/sprucelabsai/spruce-error/compare/v5.0.449...v5.0.450) (2022-05-03)

## [5.0.449](https://github.com/sprucelabsai/spruce-error/compare/v5.0.448...v5.0.449) (2022-05-02)

## [5.0.448](https://github.com/sprucelabsai/spruce-error/compare/v5.0.447...v5.0.448) (2022-04-29)

## [5.0.447](https://github.com/sprucelabsai/spruce-error/compare/v5.0.446...v5.0.447) (2022-04-27)

## [5.0.446](https://github.com/sprucelabsai/spruce-error/compare/v5.0.445...v5.0.446) (2022-04-27)

## [5.0.445](https://github.com/sprucelabsai/spruce-error/compare/v5.0.444...v5.0.445) (2022-04-26)

## [5.0.444](https://github.com/sprucelabsai/spruce-error/compare/v5.0.443...v5.0.444) (2022-04-25)

## [5.0.443](https://github.com/sprucelabsai/spruce-error/compare/v5.0.442...v5.0.443) (2022-04-25)

## [5.0.442](https://github.com/sprucelabsai/spruce-error/compare/v5.0.441...v5.0.442) (2022-04-22)

## [5.0.441](https://github.com/sprucelabsai/spruce-error/compare/v5.0.440...v5.0.441) (2022-04-22)

## [5.0.440](https://github.com/sprucelabsai/spruce-error/compare/v5.0.439...v5.0.440) (2022-04-19)

## [5.0.439](https://github.com/sprucelabsai/spruce-error/compare/v5.0.438...v5.0.439) (2022-04-09)

## [5.0.438](https://github.com/sprucelabsai/spruce-error/compare/v5.0.437...v5.0.438) (2022-04-08)

## [5.0.437](https://github.com/sprucelabsai/spruce-error/compare/v5.0.436...v5.0.437) (2022-04-06)

## [5.0.436](https://github.com/sprucelabsai/spruce-error/compare/v5.0.435...v5.0.436) (2022-04-05)

## [5.0.435](https://github.com/sprucelabsai/spruce-error/compare/v5.0.434...v5.0.435) (2022-04-03)

## [5.0.434](https://github.com/sprucelabsai/spruce-error/compare/v5.0.433...v5.0.434) (2022-04-02)

## [5.0.433](https://github.com/sprucelabsai/spruce-error/compare/v5.0.432...v5.0.433) (2022-04-02)

## [5.0.432](https://github.com/sprucelabsai/spruce-error/compare/v5.0.431...v5.0.432) (2022-03-29)

## [5.0.431](https://github.com/sprucelabsai/spruce-error/compare/v5.0.430...v5.0.431) (2022-03-29)

## [5.0.430](https://github.com/sprucelabsai/spruce-error/compare/v5.0.429...v5.0.430) (2022-03-25)

## [5.0.429](https://github.com/sprucelabsai/spruce-error/compare/v5.0.428...v5.0.429) (2022-03-25)

## [5.0.428](https://github.com/sprucelabsai/spruce-error/compare/v5.0.427...v5.0.428) (2022-03-25)

## [5.0.427](https://github.com/sprucelabsai/spruce-error/compare/v5.0.426...v5.0.427) (2022-03-25)

## [5.0.426](https://github.com/sprucelabsai/spruce-error/compare/v5.0.425...v5.0.426) (2022-03-24)

## [5.0.425](https://github.com/sprucelabsai/spruce-error/compare/v5.0.424...v5.0.425) (2022-03-22)

## [5.0.424](https://github.com/sprucelabsai/spruce-error/compare/v5.0.423...v5.0.424) (2022-03-16)

## [5.0.423](https://github.com/sprucelabsai/spruce-error/compare/v5.0.422...v5.0.423) (2022-03-14)

## [5.0.422](https://github.com/sprucelabsai/spruce-error/compare/v5.0.421...v5.0.422) (2022-03-14)

## [5.0.421](https://github.com/sprucelabsai/spruce-error/compare/v5.0.420...v5.0.421) (2022-03-14)

## [5.0.420](https://github.com/sprucelabsai/spruce-error/compare/v5.0.419...v5.0.420) (2022-03-14)

## [5.0.419](https://github.com/sprucelabsai/spruce-error/compare/v5.0.418...v5.0.419) (2022-03-13)

## [5.0.418](https://github.com/sprucelabsai/spruce-error/compare/v5.0.417...v5.0.418) (2022-03-12)

## [5.0.417](https://github.com/sprucelabsai/spruce-error/compare/v5.0.416...v5.0.417) (2022-03-11)

## [5.0.416](https://github.com/sprucelabsai/spruce-error/compare/v5.0.415...v5.0.416) (2022-03-11)

## [5.0.415](https://github.com/sprucelabsai/spruce-error/compare/v5.0.414...v5.0.415) (2022-03-11)

## [5.0.414](https://github.com/sprucelabsai/spruce-error/compare/v5.0.413...v5.0.414) (2022-03-10)

## [5.0.413](https://github.com/sprucelabsai/spruce-error/compare/v5.0.412...v5.0.413) (2022-03-10)

## [5.0.412](https://github.com/sprucelabsai/spruce-error/compare/v5.0.411...v5.0.412) (2022-03-06)

## [5.0.411](https://github.com/sprucelabsai/spruce-error/compare/v5.0.410...v5.0.411) (2022-03-04)

## [5.0.410](https://github.com/sprucelabsai/spruce-error/compare/v5.0.409...v5.0.410) (2022-03-01)

## [5.0.409](https://github.com/sprucelabsai/spruce-error/compare/v5.0.408...v5.0.409) (2022-03-01)

## [5.0.408](https://github.com/sprucelabsai/spruce-error/compare/v5.0.407...v5.0.408) (2022-03-01)

## [5.0.407](https://github.com/sprucelabsai/spruce-error/compare/v5.0.406...v5.0.407) (2022-02-26)

## [5.0.406](https://github.com/sprucelabsai/spruce-error/compare/v5.0.405...v5.0.406) (2022-02-25)

## [5.0.405](https://github.com/sprucelabsai/spruce-error/compare/v5.0.404...v5.0.405) (2022-02-23)

## [5.0.404](https://github.com/sprucelabsai/spruce-error/compare/v5.0.403...v5.0.404) (2022-02-23)

## [5.0.403](https://github.com/sprucelabsai/spruce-error/compare/v5.0.402...v5.0.403) (2022-02-23)

## [5.0.402](https://github.com/sprucelabsai/spruce-error/compare/v5.0.401...v5.0.402) (2022-02-21)

## [5.0.401](https://github.com/sprucelabsai/spruce-error/compare/v5.0.400...v5.0.401) (2022-02-17)

## [5.0.400](https://github.com/sprucelabsai/spruce-error/compare/v5.0.399...v5.0.400) (2022-02-16)

## [5.0.399](https://github.com/sprucelabsai/spruce-error/compare/v5.0.398...v5.0.399) (2022-02-16)

## [5.0.398](https://github.com/sprucelabsai/spruce-error/compare/v5.0.397...v5.0.398) (2022-02-14)

## [5.0.397](https://github.com/sprucelabsai/spruce-error/compare/v5.0.396...v5.0.397) (2022-02-12)

## [5.0.396](https://github.com/sprucelabsai/spruce-error/compare/v5.0.395...v5.0.396) (2022-02-12)

## [5.0.395](https://github.com/sprucelabsai/spruce-error/compare/v5.0.394...v5.0.395) (2022-02-10)

## [5.0.394](https://github.com/sprucelabsai/spruce-error/compare/v5.0.393...v5.0.394) (2022-02-08)

## [5.0.393](https://github.com/sprucelabsai/spruce-error/compare/v5.0.392...v5.0.393) (2022-02-08)

## [5.0.392](https://github.com/sprucelabsai/spruce-error/compare/v5.0.391...v5.0.392) (2022-02-07)

## [5.0.391](https://github.com/sprucelabsai/spruce-error/compare/v5.0.390...v5.0.391) (2022-02-07)

## [5.0.390](https://github.com/sprucelabsai/spruce-error/compare/v5.0.389...v5.0.390) (2022-02-05)

## [5.0.389](https://github.com/sprucelabsai/spruce-error/compare/v5.0.388...v5.0.389) (2022-02-05)

## [5.0.388](https://github.com/sprucelabsai/spruce-error/compare/v5.0.387...v5.0.388) (2022-02-05)

## [5.0.387](https://github.com/sprucelabsai/spruce-error/compare/v5.0.386...v5.0.387) (2022-02-01)

## [5.0.386](https://github.com/sprucelabsai/spruce-error/compare/v5.0.385...v5.0.386) (2022-01-29)

## [5.0.385](https://github.com/sprucelabsai/spruce-error/compare/v5.0.384...v5.0.385) (2022-01-28)

## [5.0.384](https://github.com/sprucelabsai/spruce-error/compare/v5.0.383...v5.0.384) (2022-01-28)

## [5.0.383](https://github.com/sprucelabsai/spruce-error/compare/v5.0.382...v5.0.383) (2022-01-25)

## [5.0.382](https://github.com/sprucelabsai/spruce-error/compare/v5.0.381...v5.0.382) (2022-01-25)

## [5.0.381](https://github.com/sprucelabsai/spruce-error/compare/v5.0.380...v5.0.381) (2022-01-20)

## [5.0.380](https://github.com/sprucelabsai/spruce-error/compare/v5.0.379...v5.0.380) (2022-01-20)

## [5.0.379](https://github.com/sprucelabsai/spruce-error/compare/v5.0.378...v5.0.379) (2022-01-20)

## [5.0.378](https://github.com/sprucelabsai/spruce-error/compare/v5.0.377...v5.0.378) (2022-01-19)

## [5.0.377](https://github.com/sprucelabsai/spruce-error/compare/v5.0.376...v5.0.377) (2022-01-19)

## [5.0.376](https://github.com/sprucelabsai/spruce-error/compare/v5.0.375...v5.0.376) (2022-01-17)

## [5.0.375](https://github.com/sprucelabsai/spruce-error/compare/v5.0.374...v5.0.375) (2022-01-16)

## [5.0.374](https://github.com/sprucelabsai/spruce-error/compare/v5.0.373...v5.0.374) (2022-01-16)

## [5.0.373](https://github.com/sprucelabsai/spruce-error/compare/v5.0.372...v5.0.373) (2022-01-15)

## [5.0.372](https://github.com/sprucelabsai/spruce-error/compare/v5.0.371...v5.0.372) (2022-01-14)

## [5.0.371](https://github.com/sprucelabsai/spruce-error/compare/v5.0.370...v5.0.371) (2022-01-14)

## [5.0.370](https://github.com/sprucelabsai/spruce-error/compare/v5.0.369...v5.0.370) (2022-01-05)

## [5.0.369](https://github.com/sprucelabsai/spruce-error/compare/v5.0.368...v5.0.369) (2022-01-05)

## [5.0.368](https://github.com/sprucelabsai/spruce-error/compare/v5.0.367...v5.0.368) (2022-01-05)

## [5.0.367](https://github.com/sprucelabsai/spruce-error/compare/v5.0.366...v5.0.367) (2022-01-05)

## [5.0.366](https://github.com/sprucelabsai/spruce-error/compare/v5.0.365...v5.0.366) (2022-01-05)

## [5.0.365](https://github.com/sprucelabsai/spruce-error/compare/v5.0.364...v5.0.365) (2022-01-05)

## [5.0.364](https://github.com/sprucelabsai/spruce-error/compare/v5.0.363...v5.0.364) (2022-01-03)

## [5.0.363](https://github.com/sprucelabsai/spruce-error/compare/v5.0.362...v5.0.363) (2022-01-03)

## [5.0.362](https://github.com/sprucelabsai/spruce-error/compare/v5.0.361...v5.0.362) (2022-01-03)

## [5.0.361](https://github.com/sprucelabsai/spruce-error/compare/v5.0.360...v5.0.361) (2022-01-01)

## [5.0.360](https://github.com/sprucelabsai/spruce-error/compare/v5.0.359...v5.0.360) (2022-01-01)

## [5.0.359](https://github.com/sprucelabsai/spruce-error/compare/v5.0.358...v5.0.359) (2022-01-01)

## [5.0.358](https://github.com/sprucelabsai/spruce-error/compare/v5.0.357...v5.0.358) (2021-12-31)

## [5.0.357](https://github.com/sprucelabsai/spruce-error/compare/v5.0.356...v5.0.357) (2021-12-31)

## [5.0.356](https://github.com/sprucelabsai/spruce-error/compare/v5.0.355...v5.0.356) (2021-12-26)

## [5.0.355](https://github.com/sprucelabsai/spruce-error/compare/v5.0.354...v5.0.355) (2021-12-23)

## [5.0.354](https://github.com/sprucelabsai/spruce-error/compare/v5.0.353...v5.0.354) (2021-12-23)

## [5.0.353](https://github.com/sprucelabsai/spruce-error/compare/v5.0.352...v5.0.353) (2021-12-21)

## [5.0.352](https://github.com/sprucelabsai/spruce-error/compare/v5.0.351...v5.0.352) (2021-12-20)

## [5.0.351](https://github.com/sprucelabsai/spruce-error/compare/v5.0.350...v5.0.351) (2021-12-20)

## [5.0.350](https://github.com/sprucelabsai/spruce-error/compare/v5.0.349...v5.0.350) (2021-12-19)

## [5.0.349](https://github.com/sprucelabsai/spruce-error/compare/v5.0.348...v5.0.349) (2021-12-19)

## [5.0.348](https://github.com/sprucelabsai/spruce-error/compare/v5.0.347...v5.0.348) (2021-12-19)

## [5.0.347](https://github.com/sprucelabsai/spruce-error/compare/v5.0.346...v5.0.347) (2021-12-18)

## [5.0.346](https://github.com/sprucelabsai/spruce-error/compare/v5.0.345...v5.0.346) (2021-12-18)

## [5.0.345](https://github.com/sprucelabsai/spruce-error/compare/v5.0.344...v5.0.345) (2021-12-18)

## [5.0.344](https://github.com/sprucelabsai/spruce-error/compare/v5.0.343...v5.0.344) (2021-12-18)

## [5.0.343](https://github.com/sprucelabsai/spruce-error/compare/v5.0.342...v5.0.343) (2021-12-17)

## [5.0.342](https://github.com/sprucelabsai/spruce-error/compare/v5.0.341...v5.0.342) (2021-12-17)

## [5.0.341](https://github.com/sprucelabsai/spruce-error/compare/v5.0.340...v5.0.341) (2021-12-17)

## [5.0.340](https://github.com/sprucelabsai/spruce-error/compare/v5.0.339...v5.0.340) (2021-12-16)

## [5.0.339](https://github.com/sprucelabsai/spruce-error/compare/v5.0.338...v5.0.339) (2021-12-16)

## [5.0.338](https://github.com/sprucelabsai/spruce-error/compare/v5.0.337...v5.0.338) (2021-12-15)

## [5.0.337](https://github.com/sprucelabsai/spruce-error/compare/v5.0.336...v5.0.337) (2021-12-15)

## [5.0.336](https://github.com/sprucelabsai/spruce-error/compare/v5.0.335...v5.0.336) (2021-12-14)

## [5.0.335](https://github.com/sprucelabsai/spruce-error/compare/v5.0.334...v5.0.335) (2021-12-14)

## [5.0.334](https://github.com/sprucelabsai/spruce-error/compare/v5.0.333...v5.0.334) (2021-12-13)

## [5.0.333](https://github.com/sprucelabsai/spruce-error/compare/v5.0.332...v5.0.333) (2021-12-13)

## [5.0.332](https://github.com/sprucelabsai/spruce-error/compare/v5.0.331...v5.0.332) (2021-12-10)

## [5.0.331](https://github.com/sprucelabsai/spruce-error/compare/v5.0.330...v5.0.331) (2021-12-10)

## [5.0.330](https://github.com/sprucelabsai/spruce-error/compare/v5.0.329...v5.0.330) (2021-12-10)

## [5.0.329](https://github.com/sprucelabsai/spruce-error/compare/v5.0.328...v5.0.329) (2021-12-09)

## [5.0.328](https://github.com/sprucelabsai/spruce-error/compare/v5.0.327...v5.0.328) (2021-12-09)

## [5.0.327](https://github.com/sprucelabsai/spruce-error/compare/v5.0.326...v5.0.327) (2021-12-09)

## [5.0.326](https://github.com/sprucelabsai/spruce-error/compare/v5.0.325...v5.0.326) (2021-12-09)

## [5.0.325](https://github.com/sprucelabsai/spruce-error/compare/v5.0.324...v5.0.325) (2021-12-09)

## [5.0.324](https://github.com/sprucelabsai/spruce-error/compare/v5.0.323...v5.0.324) (2021-12-09)

## [5.0.323](https://github.com/sprucelabsai/spruce-error/compare/v5.0.322...v5.0.323) (2021-12-09)

## [5.0.322](https://github.com/sprucelabsai/spruce-error/compare/v5.0.321...v5.0.322) (2021-12-08)

## [5.0.321](https://github.com/sprucelabsai/spruce-error/compare/v5.0.320...v5.0.321) (2021-12-07)

## [5.0.320](https://github.com/sprucelabsai/spruce-error/compare/v5.0.319...v5.0.320) (2021-12-07)

## [5.0.319](https://github.com/sprucelabsai/spruce-error/compare/v5.0.318...v5.0.319) (2021-12-07)

## [5.0.318](https://github.com/sprucelabsai/spruce-error/compare/v5.0.317...v5.0.318) (2021-12-07)

## [5.0.317](https://github.com/sprucelabsai/spruce-error/compare/v5.0.316...v5.0.317) (2021-12-05)

## [5.0.316](https://github.com/sprucelabsai/spruce-error/compare/v5.0.315...v5.0.316) (2021-12-04)

## [5.0.315](https://github.com/sprucelabsai/spruce-error/compare/v5.0.314...v5.0.315) (2021-12-04)

## [5.0.314](https://github.com/sprucelabsai/spruce-error/compare/v5.0.313...v5.0.314) (2021-12-04)

## [5.0.313](https://github.com/sprucelabsai/spruce-error/compare/v5.0.312...v5.0.313) (2021-12-04)

## [5.0.312](https://github.com/sprucelabsai/spruce-error/compare/v5.0.311...v5.0.312) (2021-12-04)

## [5.0.311](https://github.com/sprucelabsai/spruce-error/compare/v5.0.310...v5.0.311) (2021-12-04)

## [5.0.310](https://github.com/sprucelabsai/spruce-error/compare/v5.0.309...v5.0.310) (2021-12-01)

## [5.0.309](https://github.com/sprucelabsai/spruce-error/compare/v5.0.308...v5.0.309) (2021-12-01)

## [5.0.308](https://github.com/sprucelabsai/spruce-error/compare/v5.0.307...v5.0.308) (2021-11-30)

## [5.0.307](https://github.com/sprucelabsai/spruce-error/compare/v5.0.306...v5.0.307) (2021-11-30)

## [5.0.306](https://github.com/sprucelabsai/spruce-error/compare/v5.0.305...v5.0.306) (2021-11-30)

## [5.0.305](https://github.com/sprucelabsai/spruce-error/compare/v5.0.304...v5.0.305) (2021-11-30)

## [5.0.304](https://github.com/sprucelabsai/spruce-error/compare/v5.0.303...v5.0.304) (2021-11-30)

## [5.0.303](https://github.com/sprucelabsai/spruce-error/compare/v5.0.302...v5.0.303) (2021-11-26)

## [5.0.302](https://github.com/sprucelabsai/spruce-error/compare/v5.0.301...v5.0.302) (2021-11-26)

## [5.0.301](https://github.com/sprucelabsai/spruce-error/compare/v5.0.300...v5.0.301) (2021-11-26)

## [5.0.300](https://github.com/sprucelabsai/spruce-error/compare/v5.0.299...v5.0.300) (2021-11-26)

## [5.0.299](https://github.com/sprucelabsai/spruce-error/compare/v5.0.298...v5.0.299) (2021-11-25)

## [5.0.298](https://github.com/sprucelabsai/spruce-error/compare/v5.0.297...v5.0.298) (2021-11-25)

## [5.0.297](https://github.com/sprucelabsai/spruce-error/compare/v5.0.296...v5.0.297) (2021-11-25)

## [5.0.296](https://github.com/sprucelabsai/spruce-error/compare/v5.0.295...v5.0.296) (2021-11-25)

## [5.0.295](https://github.com/sprucelabsai/spruce-error/compare/v5.0.294...v5.0.295) (2021-11-25)

## [5.0.294](https://github.com/sprucelabsai/spruce-error/compare/v5.0.293...v5.0.294) (2021-11-25)

## [5.0.293](https://github.com/sprucelabsai/spruce-error/compare/v5.0.292...v5.0.293) (2021-11-25)

## [5.0.292](https://github.com/sprucelabsai/spruce-error/compare/v5.0.291...v5.0.292) (2021-11-25)

## [5.0.291](https://github.com/sprucelabsai/spruce-error/compare/v5.0.290...v5.0.291) (2021-11-23)

## [5.0.290](https://github.com/sprucelabsai/spruce-error/compare/v5.0.289...v5.0.290) (2021-11-23)

## [5.0.289](https://github.com/sprucelabsai/spruce-error/compare/v5.0.288...v5.0.289) (2021-11-21)

## [5.0.288](https://github.com/sprucelabsai/spruce-error/compare/v5.0.287...v5.0.288) (2021-11-21)

## [5.0.287](https://github.com/sprucelabsai/spruce-error/compare/v5.0.286...v5.0.287) (2021-11-21)

## [5.0.286](https://github.com/sprucelabsai/spruce-error/compare/v5.0.285...v5.0.286) (2021-11-20)

## [5.0.285](https://github.com/sprucelabsai/spruce-error/compare/v5.0.284...v5.0.285) (2021-11-19)

## [5.0.284](https://github.com/sprucelabsai/spruce-error/compare/v5.0.283...v5.0.284) (2021-11-19)

## [5.0.283](https://github.com/sprucelabsai/spruce-error/compare/v5.0.282...v5.0.283) (2021-11-18)

## [5.0.282](https://github.com/sprucelabsai/spruce-error/compare/v5.0.281...v5.0.282) (2021-11-18)

## [5.0.281](https://github.com/sprucelabsai/spruce-error/compare/v5.0.280...v5.0.281) (2021-11-17)

## [5.0.280](https://github.com/sprucelabsai/spruce-error/compare/v5.0.279...v5.0.280) (2021-11-17)

## [5.0.279](https://github.com/sprucelabsai/spruce-error/compare/v5.0.278...v5.0.279) (2021-11-17)

## [5.0.278](https://github.com/sprucelabsai/spruce-error/compare/v5.0.277...v5.0.278) (2021-11-15)

## [5.0.277](https://github.com/sprucelabsai/spruce-error/compare/v5.0.276...v5.0.277) (2021-11-13)

## [5.0.276](https://github.com/sprucelabsai/spruce-error/compare/v5.0.275...v5.0.276) (2021-11-13)

## [5.0.275](https://github.com/sprucelabsai/spruce-error/compare/v5.0.274...v5.0.275) (2021-11-13)

## [5.0.274](https://github.com/sprucelabsai/spruce-error/compare/v5.0.273...v5.0.274) (2021-11-08)

## [5.0.273](https://github.com/sprucelabsai/spruce-error/compare/v5.0.272...v5.0.273) (2021-11-08)

## [5.0.272](https://github.com/sprucelabsai/spruce-error/compare/v5.0.271...v5.0.272) (2021-11-06)

## [5.0.271](https://github.com/sprucelabsai/spruce-error/compare/v5.0.270...v5.0.271) (2021-11-06)

## [5.0.270](https://github.com/sprucelabsai/spruce-error/compare/v5.0.269...v5.0.270) (2021-11-05)

## [5.0.269](https://github.com/sprucelabsai/spruce-error/compare/v5.0.268...v5.0.269) (2021-11-05)

## [5.0.268](https://github.com/sprucelabsai/spruce-error/compare/v5.0.267...v5.0.268) (2021-11-04)

## [5.0.267](https://github.com/sprucelabsai/spruce-error/compare/v5.0.266...v5.0.267) (2021-11-04)

## [5.0.266](https://github.com/sprucelabsai/spruce-error/compare/v5.0.265...v5.0.266) (2021-11-04)

## [5.0.265](https://github.com/sprucelabsai/spruce-error/compare/v5.0.264...v5.0.265) (2021-10-30)

## [5.0.264](https://github.com/sprucelabsai/spruce-error/compare/v5.0.263...v5.0.264) (2021-10-30)

## [5.0.263](https://github.com/sprucelabsai/spruce-error/compare/v5.0.262...v5.0.263) (2021-10-30)

## [5.0.262](https://github.com/sprucelabsai/spruce-error/compare/v5.0.261...v5.0.262) (2021-10-26)

## [5.0.261](https://github.com/sprucelabsai/spruce-error/compare/v5.0.260...v5.0.261) (2021-10-26)

## [5.0.260](https://github.com/sprucelabsai/spruce-error/compare/v5.0.259...v5.0.260) (2021-10-25)

## [5.0.259](https://github.com/sprucelabsai/spruce-error/compare/v5.0.258...v5.0.259) (2021-10-25)

## [5.0.258](https://github.com/sprucelabsai/spruce-error/compare/v5.0.257...v5.0.258) (2021-10-23)

## [5.0.257](https://github.com/sprucelabsai/spruce-error/compare/v5.0.256...v5.0.257) (2021-10-22)

## [5.0.256](https://github.com/sprucelabsai/spruce-error/compare/v5.0.255...v5.0.256) (2021-10-22)

## [5.0.255](https://github.com/sprucelabsai/spruce-error/compare/v5.0.254...v5.0.255) (2021-10-22)

## [5.0.254](https://github.com/sprucelabsai/spruce-error/compare/v5.0.253...v5.0.254) (2021-10-22)

## [5.0.253](https://github.com/sprucelabsai/spruce-error/compare/v5.0.252...v5.0.253) (2021-10-22)

## [5.0.252](https://github.com/sprucelabsai/spruce-error/compare/v5.0.251...v5.0.252) (2021-10-22)

## [5.0.251](https://github.com/sprucelabsai/spruce-error/compare/v5.0.250...v5.0.251) (2021-10-22)

## [5.0.250](https://github.com/sprucelabsai/spruce-error/compare/v5.0.249...v5.0.250) (2021-10-21)

## [5.0.249](https://github.com/sprucelabsai/spruce-error/compare/v5.0.248...v5.0.249) (2021-10-21)

## [5.0.248](https://github.com/sprucelabsai/spruce-error/compare/v5.0.247...v5.0.248) (2021-10-21)

## [5.0.247](https://github.com/sprucelabsai/spruce-error/compare/v5.0.246...v5.0.247) (2021-10-21)

## [5.0.246](https://github.com/sprucelabsai/spruce-error/compare/v5.0.245...v5.0.246) (2021-10-20)

## [5.0.245](https://github.com/sprucelabsai/spruce-error/compare/v5.0.244...v5.0.245) (2021-10-20)

## [5.0.244](https://github.com/sprucelabsai/spruce-error/compare/v5.0.243...v5.0.244) (2021-10-20)

## [5.0.243](https://github.com/sprucelabsai/spruce-error/compare/v5.0.242...v5.0.243) (2021-10-19)

## [5.0.242](https://github.com/sprucelabsai/spruce-error/compare/v5.0.241...v5.0.242) (2021-10-19)

## [5.0.241](https://github.com/sprucelabsai/spruce-error/compare/v5.0.240...v5.0.241) (2021-10-19)

## [5.0.240](https://github.com/sprucelabsai/spruce-error/compare/v5.0.239...v5.0.240) (2021-10-19)

## [5.0.239](https://github.com/sprucelabsai/spruce-error/compare/v5.0.238...v5.0.239) (2021-10-19)

## [5.0.238](https://github.com/sprucelabsai/spruce-error/compare/v5.0.237...v5.0.238) (2021-10-17)

## [5.0.237](https://github.com/sprucelabsai/spruce-error/compare/v5.0.236...v5.0.237) (2021-10-17)

## [5.0.236](https://github.com/sprucelabsai/spruce-error/compare/v5.0.235...v5.0.236) (2021-10-17)

## [5.0.235](https://github.com/sprucelabsai/spruce-error/compare/v5.0.234...v5.0.235) (2021-10-17)

## [5.0.234](https://github.com/sprucelabsai/spruce-error/compare/v5.0.233...v5.0.234) (2021-10-17)

## [5.0.233](https://github.com/sprucelabsai/spruce-error/compare/v5.0.232...v5.0.233) (2021-10-16)

## [5.0.232](https://github.com/sprucelabsai/spruce-error/compare/v5.0.231...v5.0.232) (2021-10-14)

## [5.0.231](https://github.com/sprucelabsai/spruce-error/compare/v5.0.230...v5.0.231) (2021-10-14)

## [5.0.230](https://github.com/sprucelabsai/spruce-error/compare/v5.0.229...v5.0.230) (2021-10-14)

## [5.0.229](https://github.com/sprucelabsai/spruce-error/compare/v5.0.228...v5.0.229) (2021-10-14)

## [5.0.228](https://github.com/sprucelabsai/spruce-error/compare/v5.0.227...v5.0.228) (2021-10-14)

## [5.0.227](https://github.com/sprucelabsai/spruce-error/compare/v5.0.226...v5.0.227) (2021-10-13)

## [5.0.226](https://github.com/sprucelabsai/spruce-error/compare/v5.0.225...v5.0.226) (2021-10-13)

## [5.0.225](https://github.com/sprucelabsai/spruce-error/compare/v5.0.224...v5.0.225) (2021-10-13)

## [5.0.224](https://github.com/sprucelabsai/spruce-error/compare/v5.0.223...v5.0.224) (2021-10-13)

## [5.0.223](https://github.com/sprucelabsai/spruce-error/compare/v5.0.222...v5.0.223) (2021-10-13)

## [5.0.222](https://github.com/sprucelabsai/spruce-error/compare/v5.0.221...v5.0.222) (2021-10-12)

## [5.0.221](https://github.com/sprucelabsai/spruce-error/compare/v5.0.220...v5.0.221) (2021-10-12)

## [5.0.220](https://github.com/sprucelabsai/spruce-error/compare/v5.0.219...v5.0.220) (2021-10-12)

## [5.0.219](https://github.com/sprucelabsai/spruce-error/compare/v5.0.218...v5.0.219) (2021-10-12)

## [5.0.218](https://github.com/sprucelabsai/spruce-error/compare/v5.0.217...v5.0.218) (2021-10-12)

## [5.0.217](https://github.com/sprucelabsai/spruce-error/compare/v5.0.216...v5.0.217) (2021-10-12)

## [5.0.216](https://github.com/sprucelabsai/spruce-error/compare/v5.0.215...v5.0.216) (2021-10-12)

## [5.0.215](https://github.com/sprucelabsai/spruce-error/compare/v5.0.214...v5.0.215) (2021-10-08)

## [5.0.214](https://github.com/sprucelabsai/spruce-error/compare/v5.0.213...v5.0.214) (2021-10-08)

## [5.0.213](https://github.com/sprucelabsai/spruce-error/compare/v5.0.212...v5.0.213) (2021-10-08)

## [5.0.212](https://github.com/sprucelabsai/spruce-error/compare/v5.0.211...v5.0.212) (2021-10-08)

## [5.0.211](https://github.com/sprucelabsai/spruce-error/compare/v5.0.210...v5.0.211) (2021-10-05)

## [5.0.210](https://github.com/sprucelabsai/spruce-error/compare/v5.0.209...v5.0.210) (2021-10-05)

## [5.0.209](https://github.com/sprucelabsai/spruce-error/compare/v5.0.208...v5.0.209) (2021-10-04)

## [5.0.208](https://github.com/sprucelabsai/spruce-error/compare/v5.0.207...v5.0.208) (2021-10-04)

## [5.0.207](https://github.com/sprucelabsai/spruce-error/compare/v5.0.206...v5.0.207) (2021-10-04)

## [5.0.206](https://github.com/sprucelabsai/spruce-error/compare/v5.0.205...v5.0.206) (2021-10-04)

## [5.0.205](https://github.com/sprucelabsai/spruce-error/compare/v5.0.204...v5.0.205) (2021-10-04)

## [5.0.204](https://github.com/sprucelabsai/spruce-error/compare/v5.0.203...v5.0.204) (2021-10-04)

## [5.0.203](https://github.com/sprucelabsai/spruce-error/compare/v5.0.202...v5.0.203) (2021-10-04)

## [5.0.202](https://github.com/sprucelabsai/spruce-error/compare/v5.0.201...v5.0.202) (2021-10-04)

## [5.0.201](https://github.com/sprucelabsai/spruce-error/compare/v5.0.200...v5.0.201) (2021-10-04)

## [5.0.200](https://github.com/sprucelabsai/spruce-error/compare/v5.0.199...v5.0.200) (2021-10-04)

## [5.0.199](https://github.com/sprucelabsai/spruce-error/compare/v5.0.198...v5.0.199) (2021-10-04)

## [5.0.198](https://github.com/sprucelabsai/spruce-error/compare/v5.0.197...v5.0.198) (2021-10-04)

## [5.0.197](https://github.com/sprucelabsai/spruce-error/compare/v5.0.196...v5.0.197) (2021-10-04)

## [5.0.196](https://github.com/sprucelabsai/spruce-error/compare/v5.0.195...v5.0.196) (2021-10-04)

## [5.0.195](https://github.com/sprucelabsai/spruce-error/compare/v5.0.194...v5.0.195) (2021-10-04)

## [5.0.194](https://github.com/sprucelabsai/spruce-error/compare/v5.0.193...v5.0.194) (2021-10-03)

## [5.0.193](https://github.com/sprucelabsai/spruce-error/compare/v5.0.192...v5.0.193) (2021-10-03)

## [5.0.192](https://github.com/sprucelabsai/spruce-error/compare/v5.0.191...v5.0.192) (2021-10-03)

## [5.0.191](https://github.com/sprucelabsai/spruce-error/compare/v5.0.190...v5.0.191) (2021-10-03)

## [5.0.190](https://github.com/sprucelabsai/spruce-error/compare/v5.0.189...v5.0.190) (2021-10-03)

## [5.0.189](https://github.com/sprucelabsai/spruce-error/compare/v5.0.188...v5.0.189) (2021-10-03)

## [5.0.188](https://github.com/sprucelabsai/spruce-error/compare/v5.0.187...v5.0.188) (2021-10-03)

## [5.0.187](https://github.com/sprucelabsai/spruce-error/compare/v5.0.186...v5.0.187) (2021-10-03)

## [5.0.186](https://github.com/sprucelabsai/spruce-error/compare/v5.0.185...v5.0.186) (2021-10-03)

## [5.0.185](https://github.com/sprucelabsai/spruce-error/compare/v5.0.184...v5.0.185) (2021-10-03)

## [5.0.184](https://github.com/sprucelabsai/spruce-error/compare/v5.0.183...v5.0.184) (2021-10-03)

## [5.0.183](https://github.com/sprucelabsai/spruce-error/compare/v5.0.182...v5.0.183) (2021-10-03)

## [5.0.182](https://github.com/sprucelabsai/spruce-error/compare/v5.0.181...v5.0.182) (2021-10-03)

## [5.0.181](https://github.com/sprucelabsai/spruce-error/compare/v5.0.180...v5.0.181) (2021-10-03)

## [5.0.180](https://github.com/sprucelabsai/spruce-error/compare/v5.0.179...v5.0.180) (2021-10-03)

## [5.0.179](https://github.com/sprucelabsai/spruce-error/compare/v5.0.178...v5.0.179) (2021-10-03)

## [5.0.178](https://github.com/sprucelabsai/spruce-error/compare/v5.0.177...v5.0.178) (2021-10-03)

## [5.0.177](https://github.com/sprucelabsai/spruce-error/compare/v5.0.176...v5.0.177) (2021-10-03)

## [5.0.176](https://github.com/sprucelabsai/spruce-error/compare/v5.0.175...v5.0.176) (2021-10-03)

## [5.0.175](https://github.com/sprucelabsai/spruce-error/compare/v5.0.174...v5.0.175) (2021-10-03)

## [5.0.174](https://github.com/sprucelabsai/spruce-error/compare/v5.0.173...v5.0.174) (2021-10-03)

## [5.0.173](https://github.com/sprucelabsai/spruce-error/compare/v5.0.172...v5.0.173) (2021-10-03)

## [5.0.172](https://github.com/sprucelabsai/spruce-error/compare/v5.0.171...v5.0.172) (2021-10-03)

## [5.0.171](https://github.com/sprucelabsai/spruce-error/compare/v5.0.170...v5.0.171) (2021-10-03)

## [5.0.170](https://github.com/sprucelabsai/spruce-error/compare/v5.0.169...v5.0.170) (2021-10-02)

## [5.0.169](https://github.com/sprucelabsai/spruce-error/compare/v5.0.168...v5.0.169) (2021-10-02)

## [5.0.168](https://github.com/sprucelabsai/spruce-error/compare/v5.0.167...v5.0.168) (2021-10-02)

## [5.0.167](https://github.com/sprucelabsai/spruce-error/compare/v5.0.166...v5.0.167) (2021-10-02)

## [5.0.166](https://github.com/sprucelabsai/spruce-error/compare/v5.0.165...v5.0.166) (2021-10-02)

## [5.0.165](https://github.com/sprucelabsai/spruce-error/compare/v5.0.164...v5.0.165) (2021-10-02)

## [5.0.164](https://github.com/sprucelabsai/spruce-error/compare/v5.0.163...v5.0.164) (2021-10-02)

## [5.0.163](https://github.com/sprucelabsai/spruce-error/compare/v5.0.162...v5.0.163) (2021-10-02)

## [5.0.162](https://github.com/sprucelabsai/spruce-error/compare/v5.0.161...v5.0.162) (2021-10-02)

## [5.0.161](https://github.com/sprucelabsai/spruce-error/compare/v5.0.160...v5.0.161) (2021-10-02)

## [5.0.160](https://github.com/sprucelabsai/spruce-error/compare/v5.0.159...v5.0.160) (2021-10-02)

## [5.0.159](https://github.com/sprucelabsai/spruce-error/compare/v5.0.158...v5.0.159) (2021-10-02)

## [5.0.158](https://github.com/sprucelabsai/spruce-error/compare/v5.0.157...v5.0.158) (2021-10-02)

## [5.0.157](https://github.com/sprucelabsai/spruce-error/compare/v5.0.156...v5.0.157) (2021-10-02)

## [5.0.156](https://github.com/sprucelabsai/spruce-error/compare/v5.0.155...v5.0.156) (2021-10-02)

## [5.0.155](https://github.com/sprucelabsai/spruce-error/compare/v5.0.154...v5.0.155) (2021-10-02)

## [5.0.154](https://github.com/sprucelabsai/spruce-error/compare/v5.0.153...v5.0.154) (2021-10-02)

## [5.0.153](https://github.com/sprucelabsai/spruce-error/compare/v5.0.152...v5.0.153) (2021-10-02)

## [5.0.152](https://github.com/sprucelabsai/spruce-error/compare/v5.0.151...v5.0.152) (2021-10-02)

## [5.0.151](https://github.com/sprucelabsai/spruce-error/compare/v5.0.150...v5.0.151) (2021-10-02)

## [5.0.150](https://github.com/sprucelabsai/spruce-error/compare/v5.0.149...v5.0.150) (2021-10-02)

## [5.0.149](https://github.com/sprucelabsai/spruce-error/compare/v5.0.148...v5.0.149) (2021-10-02)

## [5.0.148](https://github.com/sprucelabsai/spruce-error/compare/v5.0.147...v5.0.148) (2021-10-02)

## [5.0.147](https://github.com/sprucelabsai/spruce-error/compare/v5.0.146...v5.0.147) (2021-10-02)

## [5.0.146](https://github.com/sprucelabsai/spruce-error/compare/v5.0.145...v5.0.146) (2021-10-01)

## [5.0.145](https://github.com/sprucelabsai/spruce-error/compare/v5.0.144...v5.0.145) (2021-10-01)

## [5.0.144](https://github.com/sprucelabsai/spruce-error/compare/v5.0.143...v5.0.144) (2021-10-01)

## [5.0.143](https://github.com/sprucelabsai/spruce-error/compare/v5.0.142...v5.0.143) (2021-10-01)

## [5.0.142](https://github.com/sprucelabsai/spruce-error/compare/v5.0.141...v5.0.142) (2021-10-01)

## [5.0.141](https://github.com/sprucelabsai/spruce-error/compare/v5.0.140...v5.0.141) (2021-10-01)

## [5.0.140](https://github.com/sprucelabsai/spruce-error/compare/v5.0.139...v5.0.140) (2021-10-01)

## [5.0.139](https://github.com/sprucelabsai/spruce-error/compare/v5.0.138...v5.0.139) (2021-10-01)

## [5.0.138](https://github.com/sprucelabsai/spruce-error/compare/v5.0.137...v5.0.138) (2021-10-01)

## [5.0.137](https://github.com/sprucelabsai/spruce-error/compare/v5.0.136...v5.0.137) (2021-10-01)

## [5.0.136](https://github.com/sprucelabsai/spruce-error/compare/v5.0.135...v5.0.136) (2021-10-01)

## [5.0.135](https://github.com/sprucelabsai/spruce-error/compare/v5.0.134...v5.0.135) (2021-10-01)

## [5.0.134](https://github.com/sprucelabsai/spruce-error/compare/v5.0.133...v5.0.134) (2021-10-01)

## [5.0.133](https://github.com/sprucelabsai/spruce-error/compare/v5.0.132...v5.0.133) (2021-10-01)

## [5.0.132](https://github.com/sprucelabsai/spruce-error/compare/v5.0.131...v5.0.132) (2021-10-01)

## [5.0.131](https://github.com/sprucelabsai/spruce-error/compare/v5.0.130...v5.0.131) (2021-10-01)

## [5.0.130](https://github.com/sprucelabsai/spruce-error/compare/v5.0.129...v5.0.130) (2021-10-01)

## [5.0.129](https://github.com/sprucelabsai/spruce-error/compare/v5.0.128...v5.0.129) (2021-10-01)

## [5.0.128](https://github.com/sprucelabsai/spruce-error/compare/v5.0.127...v5.0.128) (2021-10-01)

## [5.0.127](https://github.com/sprucelabsai/spruce-error/compare/v5.0.126...v5.0.127) (2021-10-01)

## [5.0.126](https://github.com/sprucelabsai/spruce-error/compare/v5.0.125...v5.0.126) (2021-10-01)

## [5.0.125](https://github.com/sprucelabsai/spruce-error/compare/v5.0.124...v5.0.125) (2021-10-01)

## [5.0.124](https://github.com/sprucelabsai/spruce-error/compare/v5.0.123...v5.0.124) (2021-10-01)

## [5.0.123](https://github.com/sprucelabsai/spruce-error/compare/v5.0.122...v5.0.123) (2021-10-01)

## [5.0.122](https://github.com/sprucelabsai/spruce-error/compare/v5.0.121...v5.0.122) (2021-09-30)

## [5.0.121](https://github.com/sprucelabsai/spruce-error/compare/v5.0.120...v5.0.121) (2021-09-30)

## [5.0.120](https://github.com/sprucelabsai/spruce-error/compare/v5.0.119...v5.0.120) (2021-09-30)

## [5.0.119](https://github.com/sprucelabsai/spruce-error/compare/v5.0.118...v5.0.119) (2021-09-30)

## [5.0.118](https://github.com/sprucelabsai/spruce-error/compare/v5.0.117...v5.0.118) (2021-09-30)

## [5.0.117](https://github.com/sprucelabsai/spruce-error/compare/v5.0.116...v5.0.117) (2021-09-30)

## [5.0.116](https://github.com/sprucelabsai/spruce-error/compare/v5.0.115...v5.0.116) (2021-09-30)

## [5.0.115](https://github.com/sprucelabsai/spruce-error/compare/v5.0.114...v5.0.115) (2021-09-30)

## [5.0.114](https://github.com/sprucelabsai/spruce-error/compare/v5.0.113...v5.0.114) (2021-09-30)

## [5.0.113](https://github.com/sprucelabsai/spruce-error/compare/v5.0.112...v5.0.113) (2021-09-30)

## [5.0.112](https://github.com/sprucelabsai/spruce-error/compare/v5.0.111...v5.0.112) (2021-09-30)

## [5.0.111](https://github.com/sprucelabsai/spruce-error/compare/v5.0.110...v5.0.111) (2021-09-30)

## [5.0.110](https://github.com/sprucelabsai/spruce-error/compare/v5.0.109...v5.0.110) (2021-09-30)

## [5.0.109](https://github.com/sprucelabsai/spruce-error/compare/v5.0.108...v5.0.109) (2021-09-30)

## [5.0.108](https://github.com/sprucelabsai/spruce-error/compare/v5.0.107...v5.0.108) (2021-09-30)

## [5.0.107](https://github.com/sprucelabsai/spruce-error/compare/v5.0.106...v5.0.107) (2021-09-30)

## [5.0.106](https://github.com/sprucelabsai/spruce-error/compare/v5.0.105...v5.0.106) (2021-09-30)

## [5.0.105](https://github.com/sprucelabsai/spruce-error/compare/v5.0.104...v5.0.105) (2021-09-30)

## [5.0.104](https://github.com/sprucelabsai/spruce-error/compare/v5.0.103...v5.0.104) (2021-09-30)

## [5.0.103](https://github.com/sprucelabsai/spruce-error/compare/v5.0.102...v5.0.103) (2021-09-30)

## [5.0.102](https://github.com/sprucelabsai/spruce-error/compare/v5.0.101...v5.0.102) (2021-09-30)

## [5.0.101](https://github.com/sprucelabsai/spruce-error/compare/v5.0.100...v5.0.101) (2021-09-30)

## [5.0.100](https://github.com/sprucelabsai/spruce-error/compare/v5.0.99...v5.0.100) (2021-09-30)

## [5.0.99](https://github.com/sprucelabsai/spruce-error/compare/v5.0.98...v5.0.99) (2021-09-29)

## [5.0.98](https://github.com/sprucelabsai/spruce-error/compare/v5.0.97...v5.0.98) (2021-09-29)

## [5.0.97](https://github.com/sprucelabsai/spruce-error/compare/v5.0.96...v5.0.97) (2021-09-29)

## [5.0.96](https://github.com/sprucelabsai/spruce-error/compare/v5.0.95...v5.0.96) (2021-09-29)

## [5.0.95](https://github.com/sprucelabsai/spruce-error/compare/v5.0.94...v5.0.95) (2021-09-29)

## [5.0.94](https://github.com/sprucelabsai/spruce-error/compare/v5.0.93...v5.0.94) (2021-09-29)

## [5.0.93](https://github.com/sprucelabsai/spruce-error/compare/v5.0.92...v5.0.93) (2021-09-29)

## [5.0.92](https://github.com/sprucelabsai/spruce-error/compare/v5.0.91...v5.0.92) (2021-09-29)

## [5.0.91](https://github.com/sprucelabsai/spruce-error/compare/v5.0.90...v5.0.91) (2021-09-29)

## [5.0.90](https://github.com/sprucelabsai/spruce-error/compare/v5.0.89...v5.0.90) (2021-09-29)

## [5.0.89](https://github.com/sprucelabsai/spruce-error/compare/v5.0.88...v5.0.89) (2021-09-29)

## [5.0.88](https://github.com/sprucelabsai/spruce-error/compare/v5.0.87...v5.0.88) (2021-09-28)

## [5.0.87](https://github.com/sprucelabsai/spruce-error/compare/v5.0.86...v5.0.87) (2021-09-28)

## [5.0.86](https://github.com/sprucelabsai/spruce-error/compare/v5.0.85...v5.0.86) (2021-09-28)

## [5.0.85](https://github.com/sprucelabsai/spruce-error/compare/v5.0.84...v5.0.85) (2021-09-28)

## [5.0.84](https://github.com/sprucelabsai/spruce-error/compare/v5.0.83...v5.0.84) (2021-09-27)

## [5.0.83](https://github.com/sprucelabsai/spruce-error/compare/v5.0.82...v5.0.83) (2021-09-27)

## [5.0.82](https://github.com/sprucelabsai/spruce-error/compare/v5.0.81...v5.0.82) (2021-09-27)

## [5.0.81](https://github.com/sprucelabsai/spruce-error/compare/v5.0.80...v5.0.81) (2021-09-27)

## [5.0.80](https://github.com/sprucelabsai/spruce-error/compare/v5.0.79...v5.0.80) (2021-09-27)

## [5.0.79](https://github.com/sprucelabsai/spruce-error/compare/v5.0.78...v5.0.79) (2021-09-27)

## [5.0.78](https://github.com/sprucelabsai/spruce-error/compare/v5.0.77...v5.0.78) (2021-09-27)

## [5.0.77](https://github.com/sprucelabsai/spruce-error/compare/v5.0.76...v5.0.77) (2021-09-27)

## [5.0.76](https://github.com/sprucelabsai/spruce-error/compare/v5.0.75...v5.0.76) (2021-09-26)

## [5.0.75](https://github.com/sprucelabsai/spruce-error/compare/v5.0.74...v5.0.75) (2021-09-26)

## [5.0.74](https://github.com/sprucelabsai/spruce-error/compare/v5.0.73...v5.0.74) (2021-09-26)

## [5.0.73](https://github.com/sprucelabsai/spruce-error/compare/v5.0.72...v5.0.73) (2021-09-26)

## [5.0.72](https://github.com/sprucelabsai/spruce-error/compare/v5.0.71...v5.0.72) (2021-09-26)

## [5.0.71](https://github.com/sprucelabsai/spruce-error/compare/v5.0.70...v5.0.71) (2021-09-25)

## [5.0.70](https://github.com/sprucelabsai/spruce-error/compare/v5.0.69...v5.0.70) (2021-09-25)

## [5.0.69](https://github.com/sprucelabsai/spruce-error/compare/v5.0.68...v5.0.69) (2021-09-25)

## [5.0.68](https://github.com/sprucelabsai/spruce-error/compare/v5.0.67...v5.0.68) (2021-09-25)

## [5.0.67](https://github.com/sprucelabsai/spruce-error/compare/v5.0.66...v5.0.67) (2021-09-25)

## [5.0.66](https://github.com/sprucelabsai/spruce-error/compare/v5.0.65...v5.0.66) (2021-09-25)

## [5.0.65](https://github.com/sprucelabsai/spruce-error/compare/v5.0.64...v5.0.65) (2021-09-25)

## [5.0.64](https://github.com/sprucelabsai/spruce-error/compare/v5.0.63...v5.0.64) (2021-09-25)

## [5.0.63](https://github.com/sprucelabsai/spruce-error/compare/v5.0.62...v5.0.63) (2021-09-25)

## [5.0.62](https://github.com/sprucelabsai/spruce-error/compare/v5.0.61...v5.0.62) (2021-09-25)

## [5.0.61](https://github.com/sprucelabsai/spruce-error/compare/v5.0.60...v5.0.61) (2021-09-25)

## [5.0.60](https://github.com/sprucelabsai/spruce-error/compare/v5.0.59...v5.0.60) (2021-09-25)

## [5.0.59](https://github.com/sprucelabsai/spruce-error/compare/v5.0.58...v5.0.59) (2021-09-25)

## [5.0.58](https://github.com/sprucelabsai/spruce-error/compare/v5.0.57...v5.0.58) (2021-09-24)

## [5.0.57](https://github.com/sprucelabsai/spruce-error/compare/v5.0.56...v5.0.57) (2021-09-24)

## [5.0.56](https://github.com/sprucelabsai/spruce-error/compare/v5.0.55...v5.0.56) (2021-09-24)

## [5.0.55](https://github.com/sprucelabsai/spruce-error/compare/v5.0.54...v5.0.55) (2021-09-24)

## [5.0.54](https://github.com/sprucelabsai/spruce-error/compare/v5.0.53...v5.0.54) (2021-09-24)

## [5.0.53](https://github.com/sprucelabsai/spruce-error/compare/v5.0.52...v5.0.53) (2021-09-24)

## [5.0.52](https://github.com/sprucelabsai/spruce-error/compare/v5.0.51...v5.0.52) (2021-09-24)

## [5.0.51](https://github.com/sprucelabsai/spruce-error/compare/v5.0.50...v5.0.51) (2021-09-23)

## [5.0.50](https://github.com/sprucelabsai/spruce-error/compare/v5.0.49...v5.0.50) (2021-09-23)

## [5.0.49](https://github.com/sprucelabsai/spruce-error/compare/v5.0.48...v5.0.49) (2021-09-23)

## [5.0.48](https://github.com/sprucelabsai/spruce-error/compare/v5.0.47...v5.0.48) (2021-09-23)

## [5.0.47](https://github.com/sprucelabsai/spruce-error/compare/v5.0.46...v5.0.47) (2021-09-22)

## [5.0.46](https://github.com/sprucelabsai/spruce-error/compare/v5.0.45...v5.0.46) (2021-09-22)

## [5.0.45](https://github.com/sprucelabsai/spruce-error/compare/v5.0.44...v5.0.45) (2021-09-22)

## [5.0.44](https://github.com/sprucelabsai/spruce-error/compare/v5.0.43...v5.0.44) (2021-09-22)

## [5.0.43](https://github.com/sprucelabsai/spruce-error/compare/v5.0.42...v5.0.43) (2021-09-22)

## [5.0.42](https://github.com/sprucelabsai/spruce-error/compare/v5.0.41...v5.0.42) (2021-09-22)

## [5.0.41](https://github.com/sprucelabsai/spruce-error/compare/v5.0.40...v5.0.41) (2021-09-22)

## [5.0.40](https://github.com/sprucelabsai/spruce-error/compare/v5.0.39...v5.0.40) (2021-09-21)

## [5.0.39](https://github.com/sprucelabsai/spruce-error/compare/v5.0.38...v5.0.39) (2021-09-21)

## [5.0.38](https://github.com/sprucelabsai/spruce-error/compare/v5.0.37...v5.0.38) (2021-09-21)

## [5.0.37](https://github.com/sprucelabsai/spruce-error/compare/v5.0.36...v5.0.37) (2021-09-21)

## [5.0.36](https://github.com/sprucelabsai/spruce-error/compare/v5.0.35...v5.0.36) (2021-09-21)

## [5.0.35](https://github.com/sprucelabsai/spruce-error/compare/v5.0.34...v5.0.35) (2021-09-20)

## [5.0.34](https://github.com/sprucelabsai/spruce-error/compare/v5.0.33...v5.0.34) (2021-09-20)

## [5.0.33](https://github.com/sprucelabsai/spruce-error/compare/v5.0.32...v5.0.33) (2021-09-20)

## [5.0.32](https://github.com/sprucelabsai/spruce-error/compare/v5.0.31...v5.0.32) (2021-09-20)

## [5.0.31](https://github.com/sprucelabsai/spruce-error/compare/v5.0.30...v5.0.31) (2021-09-20)

## [5.0.30](https://github.com/sprucelabsai/spruce-error/compare/v5.0.29...v5.0.30) (2021-09-20)

## [5.0.29](https://github.com/sprucelabsai/spruce-error/compare/v5.0.28...v5.0.29) (2021-09-20)

## [5.0.28](https://github.com/sprucelabsai/spruce-error/compare/v5.0.27...v5.0.28) (2021-09-20)

## [5.0.27](https://github.com/sprucelabsai/spruce-error/compare/v5.0.26...v5.0.27) (2021-09-20)

## [5.0.26](https://github.com/sprucelabsai/spruce-error/compare/v5.0.25...v5.0.26) (2021-09-19)

## [5.0.25](https://github.com/sprucelabsai/spruce-error/compare/v5.0.24...v5.0.25) (2021-09-19)

## [5.0.24](https://github.com/sprucelabsai/spruce-error/compare/v5.0.23...v5.0.24) (2021-09-19)

## [5.0.23](https://github.com/sprucelabsai/spruce-error/compare/v5.0.22...v5.0.23) (2021-09-19)

## [5.0.22](https://github.com/sprucelabsai/spruce-error/compare/v5.0.21...v5.0.22) (2021-09-19)

## [5.0.21](https://github.com/sprucelabsai/spruce-error/compare/v5.0.20...v5.0.21) (2021-09-19)

## [5.0.20](https://github.com/sprucelabsai/spruce-error/compare/v5.0.19...v5.0.20) (2021-09-19)

## [5.0.19](https://github.com/sprucelabsai/spruce-error/compare/v5.0.18...v5.0.19) (2021-09-19)

## [5.0.18](https://github.com/sprucelabsai/spruce-error/compare/v5.0.17...v5.0.18) (2021-09-19)

## [5.0.17](https://github.com/sprucelabsai/spruce-error/compare/v5.0.16...v5.0.17) (2021-09-18)

## [5.0.16](https://github.com/sprucelabsai/spruce-error/compare/v5.0.15...v5.0.16) (2021-09-18)

## [5.0.15](https://github.com/sprucelabsai/spruce-error/compare/v5.0.14...v5.0.15) (2021-09-18)

## [5.0.14](https://github.com/sprucelabsai/spruce-error/compare/v5.0.13...v5.0.14) (2021-09-18)

## [5.0.13](https://github.com/sprucelabsai/spruce-error/compare/v5.0.12...v5.0.13) (2021-09-17)

## [5.0.12](https://github.com/sprucelabsai/spruce-error/compare/v5.0.11...v5.0.12) (2021-09-17)

## [5.0.11](https://github.com/sprucelabsai/spruce-error/compare/v5.0.10...v5.0.11) (2021-09-17)

## [5.0.10](https://github.com/sprucelabsai/spruce-error/compare/v5.0.9...v5.0.10) (2021-09-17)

## [5.0.9](https://github.com/sprucelabsai/spruce-error/compare/v5.0.8...v5.0.9) (2021-09-17)

## [5.0.8](https://github.com/sprucelabsai/spruce-error/compare/v5.0.7...v5.0.8) (2021-09-17)

## [5.0.7](https://github.com/sprucelabsai/spruce-error/compare/v5.0.6...v5.0.7) (2021-09-17)

## [5.0.6](https://github.com/sprucelabsai/spruce-error/compare/v5.0.5...v5.0.6) (2021-09-16)

## [5.0.5](https://github.com/sprucelabsai/spruce-error/compare/v5.0.4...v5.0.5) (2021-09-16)

## [5.0.4](https://github.com/sprucelabsai/spruce-error/compare/v5.0.3...v5.0.4) (2021-09-16)

## [5.0.3](https://github.com/sprucelabsai/spruce-error/compare/v5.0.2...v5.0.3) (2021-09-03)

## [5.0.2](https://github.com/sprucelabsai/spruce-error/compare/v5.0.1...v5.0.2) (2021-09-03)

## [5.0.1](https://github.com/sprucelabsai/spruce-error/compare/v5.0.0...v5.0.1) (2021-08-21)

# [5.0.0](https://github.com/sprucelabsai/spruce-error/compare/v4.1.16...v5.0.0) (2021-08-21)


### Breaking Changes

* removed export of error options since they are only for testing ([f833bca](https://github.com/sprucelabsai/spruce-error/commit/f833bca))

## [4.1.16](https://github.com/sprucelabsai/spruce-error/compare/v4.1.15...v4.1.16) (2021-07-30)

## [4.1.15](https://github.com/sprucelabsai/spruce-error/compare/v4.1.14...v4.1.15) (2021-06-21)

## [4.1.14](https://github.com/sprucelabsai/spruce-error/compare/v4.1.13...v4.1.14) (2021-06-14)

## [4.1.13](https://github.com/sprucelabsai/spruce-error/compare/v4.1.12...v4.1.13) (2021-06-11)

## [4.1.12](https://github.com/sprucelabsai/spruce-error/compare/v4.1.11...v4.1.12) (2021-06-07)

## [4.1.11](https://github.com/sprucelabsai/spruce-error/compare/v4.1.10...v4.1.11) (2021-04-16)

## [4.1.10](https://github.com/sprucelabsai/spruce-error/compare/v4.1.9...v4.1.10) (2021-03-04)

## [4.1.9](https://github.com/sprucelabsai/spruce-error/compare/v4.1.8...v4.1.9) (2021-03-04)

## [4.1.8](https://github.com/sprucelabsai/spruce-error/compare/v4.1.7...v4.1.8) (2021-03-03)

## [4.1.7](https://github.com/sprucelabsai/spruce-error/compare/v4.1.6...v4.1.7) (2021-03-03)

## [4.1.6](https://github.com/sprucelabsai/spruce-error/compare/v4.1.5...v4.1.6) (2021-03-02)

## [4.1.5](https://github.com/sprucelabsai/spruce-error/compare/v4.1.4...v4.1.5) (2021-03-02)

## [4.1.4](https://github.com/sprucelabsai/spruce-error/compare/v4.1.3...v4.1.4) (2021-02-25)

## [4.1.3](https://github.com/sprucelabsai/spruce-error/compare/v4.1.2...v4.1.3) (2021-02-25)


### Bug Fixes

* fixed target to es6 ([33e0dbd](https://github.com/sprucelabsai/spruce-error/commit/33e0dbd))

## [4.1.2](https://github.com/sprucelabsai/spruce-error/compare/v4.1.1...v4.1.2) (2021-02-23)

## [4.1.1](https://github.com/sprucelabsai/spruce-error/compare/v4.1.0...v4.1.1) (2021-02-09)

# [4.1.0](https://github.com/sprucelabsai/spruce-error/compare/v4.0.6...v4.1.0) (2021-02-09)


### Features

* errors now have prettyPrint ([e7ad2e6](https://github.com/sprucelabsai/spruce-error/commit/e7ad2e6))

## [4.0.6](https://github.com/sprucelabsai/spruce-error/compare/v4.0.5...v4.0.6) (2021-01-26)

## [4.0.5](https://github.com/sprucelabsai/spruce-error/compare/v4.0.4...v4.0.5) (2021-01-20)

## [4.0.4](https://github.com/sprucelabsai/spruce-error/compare/v4.0.3...v4.0.4) (2020-12-31)

## [4.0.3](https://github.com/sprucelabsai/spruce-error/compare/v4.0.2...v4.0.3) (2020-12-28)

## [4.0.2](https://github.com/sprucelabsai/spruce-error/compare/v4.0.1...v4.0.2) (2020-12-23)

## [4.0.1](https://github.com/sprucelabsai/spruce-error/compare/v4.0.0...v4.0.1) (2020-11-30)

# [4.0.0](https://github.com/sprucelabsai/spruce-error/compare/v3.0.0...v4.0.0) (2020-11-26)


### Breaking Changes

* remove i's from interfaces ([4ce3e86](https://github.com/sprucelabsai/spruce-error/commit/4ce3e86))

# [3.0.0](https://github.com/sprucelabsai/spruce-error/compare/v2.4.1...v3.0.0) (2020-11-11)


### Breaking Changes

* no http status code ([91c8775](https://github.com/sprucelabsai/spruce-error/commit/91c8775))

## [2.4.1](https://github.com/sprucelabsai/spruce-error/compare/v2.4.0...v2.4.1) (2020-10-27)

# [2.4.0](https://github.com/sprucelabsai/spruce-error/compare/v2.3.0...v2.4.0) (2020-10-19)


### Features

* to object and better stack restoration ([febb48b](https://github.com/sprucelabsai/spruce-error/commit/febb48b))

# [2.3.0](https://github.com/sprucelabsai/spruce-error/compare/v2.2.475...v2.3.0) (2020-10-19)


### Features

* recursive error serialization ([9ee7384](https://github.com/sprucelabsai/spruce-error/commit/9ee7384))

## [2.2.475](https://github.com/sprucelabsai/spruce-error/compare/v2.2.474...v2.2.475) (2020-10-12)

## [2.2.474](https://github.com/sprucelabsai/spruce-error/compare/v2.2.473...v2.2.474) (2020-10-12)

## [2.2.473](https://github.com/sprucelabsai/spruce-error/compare/v2.2.472...v2.2.473) (2020-10-12)

## [2.2.472](https://github.com/sprucelabsai/spruce-error/compare/v2.2.471...v2.2.472) (2020-10-12)

## [2.2.471](https://github.com/sprucelabsai/spruce-error/compare/v2.2.470...v2.2.471) (2020-10-12)

## [2.2.470](https://github.com/sprucelabsai/spruce-error/compare/v2.2.469...v2.2.470) (2020-10-12)

## [2.2.469](https://github.com/sprucelabsai/spruce-error/compare/v2.2.468...v2.2.469) (2020-10-12)

## [2.2.468](https://github.com/sprucelabsai/spruce-error/compare/v2.2.467...v2.2.468) (2020-10-11)

## [2.2.467](https://github.com/sprucelabsai/spruce-error/compare/v2.2.466...v2.2.467) (2020-10-11)

## [2.2.466](https://github.com/sprucelabsai/spruce-error/compare/v2.2.465...v2.2.466) (2020-10-11)

## [2.2.465](https://github.com/sprucelabsai/spruce-error/compare/v2.2.464...v2.2.465) (2020-10-11)

## [2.2.464](https://github.com/sprucelabsai/spruce-error/compare/v2.2.463...v2.2.464) (2020-10-11)

## [2.2.463](https://github.com/sprucelabsai/spruce-error/compare/v2.2.462...v2.2.463) (2020-10-11)

## [2.2.462](https://github.com/sprucelabsai/spruce-error/compare/v2.2.461...v2.2.462) (2020-10-11)

## [2.2.461](https://github.com/sprucelabsai/spruce-error/compare/v2.2.460...v2.2.461) (2020-10-11)

## [2.2.460](https://github.com/sprucelabsai/spruce-error/compare/v2.2.459...v2.2.460) (2020-10-11)

## [2.2.459](https://github.com/sprucelabsai/spruce-error/compare/v2.2.458...v2.2.459) (2020-10-11)

## [2.2.458](https://github.com/sprucelabsai/spruce-error/compare/v2.2.457...v2.2.458) (2020-10-10)

## [2.2.457](https://github.com/sprucelabsai/spruce-error/compare/v2.2.456...v2.2.457) (2020-10-10)

## [2.2.456](https://github.com/sprucelabsai/spruce-error/compare/v2.2.455...v2.2.456) (2020-10-10)

## [2.2.455](https://github.com/sprucelabsai/spruce-error/compare/v2.2.454...v2.2.455) (2020-10-10)

## [2.2.454](https://github.com/sprucelabsai/spruce-error/compare/v2.2.453...v2.2.454) (2020-10-10)

## [2.2.453](https://github.com/sprucelabsai/spruce-error/compare/v2.2.452...v2.2.453) (2020-10-10)

## [2.2.452](https://github.com/sprucelabsai/spruce-error/compare/v2.2.451...v2.2.452) (2020-10-09)

## [2.2.451](https://github.com/sprucelabsai/spruce-error/compare/v2.2.450...v2.2.451) (2020-10-09)

## [2.2.450](https://github.com/sprucelabsai/spruce-error/compare/v2.2.449...v2.2.450) (2020-10-09)

## [2.2.449](https://github.com/sprucelabsai/spruce-error/compare/v2.2.448...v2.2.449) (2020-10-09)

## [2.2.448](https://github.com/sprucelabsai/spruce-error/compare/v2.2.447...v2.2.448) (2020-10-09)

## [2.2.447](https://github.com/sprucelabsai/spruce-error/compare/v2.2.446...v2.2.447) (2020-10-09)

## [2.2.446](https://github.com/sprucelabsai/spruce-error/compare/v2.2.445...v2.2.446) (2020-10-09)

## [2.2.445](https://github.com/sprucelabsai/spruce-error/compare/v2.2.444...v2.2.445) (2020-10-09)

## [2.2.444](https://github.com/sprucelabsai/spruce-error/compare/v2.2.443...v2.2.444) (2020-10-09)

## [2.2.443](https://github.com/sprucelabsai/spruce-error/compare/v2.2.442...v2.2.443) (2020-10-08)

## [2.2.442](https://github.com/sprucelabsai/spruce-error/compare/v2.2.441...v2.2.442) (2020-10-08)

## [2.2.441](https://github.com/sprucelabsai/spruce-error/compare/v2.2.440...v2.2.441) (2020-10-08)

## [2.2.440](https://github.com/sprucelabsai/spruce-error/compare/v2.2.439...v2.2.440) (2020-10-08)

## [2.2.439](https://github.com/sprucelabsai/spruce-error/compare/v2.2.438...v2.2.439) (2020-10-08)

## [2.2.438](https://github.com/sprucelabsai/spruce-error/compare/v2.2.437...v2.2.438) (2020-10-08)

## [2.2.437](https://github.com/sprucelabsai/spruce-error/compare/v2.2.436...v2.2.437) (2020-10-08)

## [2.2.436](https://github.com/sprucelabsai/spruce-error/compare/v2.2.435...v2.2.436) (2020-10-08)

## [2.2.435](https://github.com/sprucelabsai/spruce-error/compare/v2.2.434...v2.2.435) (2020-10-08)

## [2.2.434](https://github.com/sprucelabsai/spruce-error/compare/v2.2.433...v2.2.434) (2020-10-08)

## [2.2.433](https://github.com/sprucelabsai/spruce-error/compare/v2.2.432...v2.2.433) (2020-10-07)

## [2.2.432](https://github.com/sprucelabsai/spruce-error/compare/v2.2.431...v2.2.432) (2020-10-07)

## [2.2.431](https://github.com/sprucelabsai/spruce-error/compare/v2.2.430...v2.2.431) (2020-10-07)

## [2.2.430](https://github.com/sprucelabsai/spruce-error/compare/v2.2.429...v2.2.430) (2020-10-07)

## [2.2.429](https://github.com/sprucelabsai/spruce-error/compare/v2.2.428...v2.2.429) (2020-10-06)

## [2.2.428](https://github.com/sprucelabsai/spruce-error/compare/v2.2.427...v2.2.428) (2020-10-06)

## [2.2.427](https://github.com/sprucelabsai/spruce-error/compare/v2.2.426...v2.2.427) (2020-10-06)

## [2.2.426](https://github.com/sprucelabsai/spruce-error/compare/v2.2.425...v2.2.426) (2020-10-06)

## [2.2.425](https://github.com/sprucelabsai/spruce-error/compare/v2.2.424...v2.2.425) (2020-10-06)

## [2.2.424](https://github.com/sprucelabsai/spruce-error/compare/v2.2.423...v2.2.424) (2020-10-06)

## [2.2.423](https://github.com/sprucelabsai/spruce-error/compare/v2.2.422...v2.2.423) (2020-10-06)

## [2.2.422](https://github.com/sprucelabsai/spruce-error/compare/v2.2.421...v2.2.422) (2020-10-06)

## [2.2.421](https://github.com/sprucelabsai/spruce-error/compare/v2.2.420...v2.2.421) (2020-10-06)

## [2.2.420](https://github.com/sprucelabsai/spruce-error/compare/v2.2.419...v2.2.420) (2020-10-06)

## [2.2.419](https://github.com/sprucelabsai/spruce-error/compare/v2.2.418...v2.2.419) (2020-10-06)

## [2.2.418](https://github.com/sprucelabsai/spruce-error/compare/v2.2.417...v2.2.418) (2020-10-06)

## [2.2.417](https://github.com/sprucelabsai/spruce-error/compare/v2.2.416...v2.2.417) (2020-10-05)

## [2.2.416](https://github.com/sprucelabsai/spruce-error/compare/v2.2.415...v2.2.416) (2020-10-05)

## [2.2.415](https://github.com/sprucelabsai/spruce-error/compare/v2.2.414...v2.2.415) (2020-10-05)

## [2.2.414](https://github.com/sprucelabsai/spruce-error/compare/v2.2.413...v2.2.414) (2020-10-05)

## [2.2.413](https://github.com/sprucelabsai/spruce-error/compare/v2.2.412...v2.2.413) (2020-10-05)

## [2.2.412](https://github.com/sprucelabsai/spruce-error/compare/v2.2.411...v2.2.412) (2020-10-05)

## [2.2.411](https://github.com/sprucelabsai/spruce-error/compare/v2.2.410...v2.2.411) (2020-10-05)

## [2.2.410](https://github.com/sprucelabsai/spruce-error/compare/v2.2.409...v2.2.410) (2020-10-05)

## [2.2.409](https://github.com/sprucelabsai/spruce-error/compare/v2.2.408...v2.2.409) (2020-10-05)

## [2.2.408](https://github.com/sprucelabsai/spruce-error/compare/v2.2.407...v2.2.408) (2020-10-04)

## [2.2.407](https://github.com/sprucelabsai/spruce-error/compare/v2.2.406...v2.2.407) (2020-10-04)

## [2.2.406](https://github.com/sprucelabsai/spruce-error/compare/v2.2.405...v2.2.406) (2020-10-04)

## [2.2.405](https://github.com/sprucelabsai/spruce-error/compare/v2.2.404...v2.2.405) (2020-10-04)

## [2.2.404](https://github.com/sprucelabsai/spruce-error/compare/v2.2.403...v2.2.404) (2020-10-04)

## [2.2.403](https://github.com/sprucelabsai/spruce-error/compare/v2.2.402...v2.2.403) (2020-10-04)

## [2.2.402](https://github.com/sprucelabsai/spruce-error/compare/v2.2.401...v2.2.402) (2020-10-04)

## [2.2.401](https://github.com/sprucelabsai/spruce-error/compare/v2.2.400...v2.2.401) (2020-10-03)

## [2.2.400](https://github.com/sprucelabsai/spruce-error/compare/v2.2.399...v2.2.400) (2020-10-03)

## [2.2.399](https://github.com/sprucelabsai/spruce-error/compare/v2.2.398...v2.2.399) (2020-10-02)

## [2.2.398](https://github.com/sprucelabsai/spruce-error/compare/v2.2.397...v2.2.398) (2020-10-02)

## [2.2.397](https://github.com/sprucelabsai/spruce-error/compare/v2.2.396...v2.2.397) (2020-10-02)

## [2.2.396](https://github.com/sprucelabsai/spruce-error/compare/v2.2.395...v2.2.396) (2020-10-02)

## [2.2.395](https://github.com/sprucelabsai/spruce-error/compare/v2.2.394...v2.2.395) (2020-10-02)

## [2.2.394](https://github.com/sprucelabsai/spruce-error/compare/v2.2.393...v2.2.394) (2020-10-02)

## [2.2.393](https://github.com/sprucelabsai/spruce-error/compare/v2.2.392...v2.2.393) (2020-10-02)

## [2.2.392](https://github.com/sprucelabsai/spruce-error/compare/v2.2.391...v2.2.392) (2020-10-01)

## [2.2.391](https://github.com/sprucelabsai/spruce-error/compare/v2.2.390...v2.2.391) (2020-10-01)

## [2.2.390](https://github.com/sprucelabsai/spruce-error/compare/v2.2.389...v2.2.390) (2020-10-01)

## [2.2.389](https://github.com/sprucelabsai/spruce-error/compare/v2.2.388...v2.2.389) (2020-10-01)

## [2.2.388](https://github.com/sprucelabsai/spruce-error/compare/v2.2.387...v2.2.388) (2020-09-30)

## [2.2.387](https://github.com/sprucelabsai/spruce-error/compare/v2.2.386...v2.2.387) (2020-09-30)

## [2.2.386](https://github.com/sprucelabsai/spruce-error/compare/v2.2.385...v2.2.386) (2020-09-30)

## [2.2.385](https://github.com/sprucelabsai/spruce-error/compare/v2.2.384...v2.2.385) (2020-09-30)

## [2.2.384](https://github.com/sprucelabsai/spruce-error/compare/v2.2.383...v2.2.384) (2020-09-30)

## [2.2.383](https://github.com/sprucelabsai/spruce-error/compare/v2.2.382...v2.2.383) (2020-09-30)

## [2.2.382](https://github.com/sprucelabsai/spruce-error/compare/v2.2.381...v2.2.382) (2020-09-30)

## [2.2.381](https://github.com/sprucelabsai/spruce-error/compare/v2.2.380...v2.2.381) (2020-09-30)

## [2.2.380](https://github.com/sprucelabsai/spruce-error/compare/v2.2.379...v2.2.380) (2020-09-30)

## [2.2.379](https://github.com/sprucelabsai/spruce-error/compare/v2.2.378...v2.2.379) (2020-09-30)

## [2.2.378](https://github.com/sprucelabsai/spruce-error/compare/v2.2.377...v2.2.378) (2020-09-30)

## [2.2.377](https://github.com/sprucelabsai/spruce-error/compare/v2.2.376...v2.2.377) (2020-09-30)

## [2.2.376](https://github.com/sprucelabsai/spruce-error/compare/v2.2.375...v2.2.376) (2020-09-30)

## [2.2.375](https://github.com/sprucelabsai/spruce-error/compare/v2.2.374...v2.2.375) (2020-09-30)

## [2.2.374](https://github.com/sprucelabsai/spruce-error/compare/v2.2.373...v2.2.374) (2020-09-29)

## [2.2.373](https://github.com/sprucelabsai/spruce-error/compare/v2.2.372...v2.2.373) (2020-09-29)

## [2.2.372](https://github.com/sprucelabsai/spruce-error/compare/v2.2.371...v2.2.372) (2020-09-29)

## [2.2.371](https://github.com/sprucelabsai/spruce-error/compare/v2.2.370...v2.2.371) (2020-09-29)

## [2.2.370](https://github.com/sprucelabsai/spruce-error/compare/v2.2.369...v2.2.370) (2020-09-29)

## [2.2.369](https://github.com/sprucelabsai/spruce-error/compare/v2.2.368...v2.2.369) (2020-09-29)

## [2.2.368](https://github.com/sprucelabsai/spruce-error/compare/v2.2.367...v2.2.368) (2020-09-29)

## [2.2.367](https://github.com/sprucelabsai/spruce-error/compare/v2.2.366...v2.2.367) (2020-09-28)

## [2.2.366](https://github.com/sprucelabsai/spruce-error/compare/v2.2.365...v2.2.366) (2020-09-28)

## [2.2.365](https://github.com/sprucelabsai/spruce-error/compare/v2.2.364...v2.2.365) (2020-09-28)

## [2.2.364](https://github.com/sprucelabsai/spruce-error/compare/v2.2.363...v2.2.364) (2020-09-28)

## [2.2.363](https://github.com/sprucelabsai/spruce-error/compare/v2.2.362...v2.2.363) (2020-09-28)

## [2.2.362](https://github.com/sprucelabsai/spruce-error/compare/v2.2.361...v2.2.362) (2020-09-28)

## [2.2.361](https://github.com/sprucelabsai/spruce-error/compare/v2.2.360...v2.2.361) (2020-09-28)

## [2.2.360](https://github.com/sprucelabsai/spruce-error/compare/v2.2.359...v2.2.360) (2020-09-28)

## [2.2.359](https://github.com/sprucelabsai/spruce-error/compare/v2.2.358...v2.2.359) (2020-09-28)

## [2.2.358](https://github.com/sprucelabsai/spruce-error/compare/v2.2.357...v2.2.358) (2020-09-28)

## [2.2.357](https://github.com/sprucelabsai/spruce-error/compare/v2.2.356...v2.2.357) (2020-09-28)

## [2.2.356](https://github.com/sprucelabsai/spruce-error/compare/v2.2.355...v2.2.356) (2020-09-27)

## [2.2.355](https://github.com/sprucelabsai/spruce-error/compare/v2.2.354...v2.2.355) (2020-09-27)

## [2.2.354](https://github.com/sprucelabsai/spruce-error/compare/v2.2.353...v2.2.354) (2020-09-27)

## [2.2.353](https://github.com/sprucelabsai/spruce-error/compare/v2.2.352...v2.2.353) (2020-09-27)

## [2.2.352](https://github.com/sprucelabsai/spruce-error/compare/v2.2.351...v2.2.352) (2020-09-26)

## [2.2.351](https://github.com/sprucelabsai/spruce-error/compare/v2.2.350...v2.2.351) (2020-09-26)

## [2.2.350](https://github.com/sprucelabsai/spruce-error/compare/v2.2.349...v2.2.350) (2020-09-26)

## [2.2.349](https://github.com/sprucelabsai/spruce-error/compare/v2.2.348...v2.2.349) (2020-09-26)

## [2.2.348](https://github.com/sprucelabsai/spruce-error/compare/v2.2.347...v2.2.348) (2020-09-26)

## [2.2.347](https://github.com/sprucelabsai/spruce-error/compare/v2.2.346...v2.2.347) (2020-09-25)

## [2.2.346](https://github.com/sprucelabsai/spruce-error/compare/v2.2.345...v2.2.346) (2020-09-25)

## [2.2.345](https://github.com/sprucelabsai/spruce-error/compare/v2.2.344...v2.2.345) (2020-09-25)

## [2.2.344](https://github.com/sprucelabsai/spruce-error/compare/v2.2.343...v2.2.344) (2020-09-25)

## [2.2.343](https://github.com/sprucelabsai/spruce-error/compare/v2.2.342...v2.2.343) (2020-09-25)

## [2.2.342](https://github.com/sprucelabsai/spruce-error/compare/v2.2.341...v2.2.342) (2020-09-25)

## [2.2.341](https://github.com/sprucelabsai/spruce-error/compare/v2.2.340...v2.2.341) (2020-09-25)

## [2.2.340](https://github.com/sprucelabsai/spruce-error/compare/v2.2.339...v2.2.340) (2020-09-25)

## [2.2.339](https://github.com/sprucelabsai/spruce-error/compare/v2.2.338...v2.2.339) (2020-09-24)

## [2.2.338](https://github.com/sprucelabsai/spruce-error/compare/v2.2.337...v2.2.338) (2020-09-24)

## [2.2.337](https://github.com/sprucelabsai/spruce-error/compare/v2.2.336...v2.2.337) (2020-09-24)

## [2.2.336](https://github.com/sprucelabsai/spruce-error/compare/v2.2.335...v2.2.336) (2020-09-24)

## [2.2.335](https://github.com/sprucelabsai/spruce-error/compare/v2.2.334...v2.2.335) (2020-09-24)

## [2.2.334](https://github.com/sprucelabsai/spruce-error/compare/v2.2.333...v2.2.334) (2020-09-24)

## [2.2.333](https://github.com/sprucelabsai/spruce-error/compare/v2.2.332...v2.2.333) (2020-09-24)

## [2.2.332](https://github.com/sprucelabsai/spruce-error/compare/v2.2.331...v2.2.332) (2020-09-24)

## [2.2.331](https://github.com/sprucelabsai/spruce-error/compare/v2.2.330...v2.2.331) (2020-09-23)

## [2.2.330](https://github.com/sprucelabsai/spruce-error/compare/v2.2.329...v2.2.330) (2020-09-23)

## [2.2.329](https://github.com/sprucelabsai/spruce-error/compare/v2.2.328...v2.2.329) (2020-09-23)

## [2.2.328](https://github.com/sprucelabsai/spruce-error/compare/v2.2.327...v2.2.328) (2020-09-23)

## [2.2.327](https://github.com/sprucelabsai/spruce-error/compare/v2.2.326...v2.2.327) (2020-09-23)

## [2.2.326](https://github.com/sprucelabsai/spruce-error/compare/v2.2.325...v2.2.326) (2020-09-23)

## [2.2.325](https://github.com/sprucelabsai/spruce-error/compare/v2.2.324...v2.2.325) (2020-09-23)

## [2.2.324](https://github.com/sprucelabsai/spruce-error/compare/v2.2.323...v2.2.324) (2020-09-23)

## [2.2.323](https://github.com/sprucelabsai/spruce-error/compare/v2.2.322...v2.2.323) (2020-09-23)

## [2.2.322](https://github.com/sprucelabsai/spruce-error/compare/v2.2.321...v2.2.322) (2020-09-23)

## [2.2.321](https://github.com/sprucelabsai/spruce-error/compare/v2.2.320...v2.2.321) (2020-09-23)

## [2.2.320](https://github.com/sprucelabsai/spruce-error/compare/v2.2.319...v2.2.320) (2020-09-23)

## [2.2.319](https://github.com/sprucelabsai/spruce-error/compare/v2.2.318...v2.2.319) (2020-09-23)

## [2.2.318](https://github.com/sprucelabsai/spruce-error/compare/v2.2.317...v2.2.318) (2020-09-22)

## [2.2.317](https://github.com/sprucelabsai/spruce-error/compare/v2.2.316...v2.2.317) (2020-09-22)

## [2.2.316](https://github.com/sprucelabsai/spruce-error/compare/v2.2.315...v2.2.316) (2020-09-22)

## [2.2.315](https://github.com/sprucelabsai/spruce-error/compare/v2.2.314...v2.2.315) (2020-09-22)

## [2.2.314](https://github.com/sprucelabsai/spruce-error/compare/v2.2.313...v2.2.314) (2020-09-22)

## [2.2.313](https://github.com/sprucelabsai/spruce-error/compare/v2.2.312...v2.2.313) (2020-09-22)

## [2.2.312](https://github.com/sprucelabsai/spruce-error/compare/v2.2.311...v2.2.312) (2020-09-22)

## [2.2.311](https://github.com/sprucelabsai/spruce-error/compare/v2.2.310...v2.2.311) (2020-09-21)

## [2.2.310](https://github.com/sprucelabsai/spruce-error/compare/v2.2.309...v2.2.310) (2020-09-21)

## [2.2.309](https://github.com/sprucelabsai/spruce-error/compare/v2.2.308...v2.2.309) (2020-09-21)

## [2.2.308](https://github.com/sprucelabsai/spruce-error/compare/v2.2.307...v2.2.308) (2020-09-21)

## [2.2.307](https://github.com/sprucelabsai/spruce-error/compare/v2.2.306...v2.2.307) (2020-09-21)

## [2.2.306](https://github.com/sprucelabsai/spruce-error/compare/v2.2.305...v2.2.306) (2020-09-21)

## [2.2.305](https://github.com/sprucelabsai/spruce-error/compare/v2.2.304...v2.2.305) (2020-09-21)

## [2.2.304](https://github.com/sprucelabsai/spruce-error/compare/v2.2.303...v2.2.304) (2020-09-21)

## [2.2.303](https://github.com/sprucelabsai/spruce-error/compare/v2.2.302...v2.2.303) (2020-09-21)

## [2.2.302](https://github.com/sprucelabsai/spruce-error/compare/v2.2.301...v2.2.302) (2020-09-20)

## [2.2.301](https://github.com/sprucelabsai/spruce-error/compare/v2.2.300...v2.2.301) (2020-09-20)

## [2.2.300](https://github.com/sprucelabsai/spruce-error/compare/v2.2.299...v2.2.300) (2020-09-19)

## [2.2.299](https://github.com/sprucelabsai/spruce-error/compare/v2.2.298...v2.2.299) (2020-09-19)

## [2.2.298](https://github.com/sprucelabsai/spruce-error/compare/v2.2.297...v2.2.298) (2020-09-19)

## [2.2.297](https://github.com/sprucelabsai/spruce-error/compare/v2.2.296...v2.2.297) (2020-09-19)

## [2.2.296](https://github.com/sprucelabsai/spruce-error/compare/v2.2.295...v2.2.296) (2020-09-19)

## [2.2.295](https://github.com/sprucelabsai/spruce-error/compare/v2.2.294...v2.2.295) (2020-09-19)

## [2.2.294](https://github.com/sprucelabsai/spruce-error/compare/v2.2.293...v2.2.294) (2020-09-19)

## [2.2.293](https://github.com/sprucelabsai/spruce-error/compare/v2.2.292...v2.2.293) (2020-09-18)

## [2.2.292](https://github.com/sprucelabsai/spruce-error/compare/v2.2.291...v2.2.292) (2020-09-18)

## [2.2.291](https://github.com/sprucelabsai/spruce-error/compare/v2.2.290...v2.2.291) (2020-09-18)

## [2.2.290](https://github.com/sprucelabsai/spruce-error/compare/v2.2.289...v2.2.290) (2020-09-18)

## [2.2.289](https://github.com/sprucelabsai/spruce-error/compare/v2.2.288...v2.2.289) (2020-09-17)

## [2.2.288](https://github.com/sprucelabsai/spruce-error/compare/v2.2.287...v2.2.288) (2020-09-17)

## [2.2.287](https://github.com/sprucelabsai/spruce-error/compare/v2.2.286...v2.2.287) (2020-09-17)

## [2.2.286](https://github.com/sprucelabsai/spruce-error/compare/v2.2.285...v2.2.286) (2020-09-17)

## [2.2.285](https://github.com/sprucelabsai/spruce-error/compare/v2.2.284...v2.2.285) (2020-09-17)

## [2.2.284](https://github.com/sprucelabsai/spruce-error/compare/v2.2.283...v2.2.284) (2020-09-17)

## [2.2.283](https://github.com/sprucelabsai/spruce-error/compare/v2.2.282...v2.2.283) (2020-09-17)

## [2.2.282](https://github.com/sprucelabsai/spruce-error/compare/v2.2.281...v2.2.282) (2020-09-16)

## [2.2.281](https://github.com/sprucelabsai/spruce-error/compare/v2.2.280...v2.2.281) (2020-09-16)

## [2.2.280](https://github.com/sprucelabsai/spruce-error/compare/v2.2.279...v2.2.280) (2020-09-16)

## [2.2.279](https://github.com/sprucelabsai/spruce-error/compare/v2.2.278...v2.2.279) (2020-09-16)

## [2.2.278](https://github.com/sprucelabsai/spruce-error/compare/v2.2.277...v2.2.278) (2020-09-16)

## [2.2.277](https://github.com/sprucelabsai/spruce-error/compare/v2.2.276...v2.2.277) (2020-09-16)

## [2.2.276](https://github.com/sprucelabsai/spruce-error/compare/v2.2.275...v2.2.276) (2020-09-16)

## [2.2.275](https://github.com/sprucelabsai/spruce-error/compare/v2.2.274...v2.2.275) (2020-09-16)

## [2.2.274](https://github.com/sprucelabsai/spruce-error/compare/v2.2.273...v2.2.274) (2020-09-16)

## [2.2.273](https://github.com/sprucelabsai/spruce-error/compare/v2.2.272...v2.2.273) (2020-09-16)

## [2.2.272](https://github.com/sprucelabsai/spruce-error/compare/v2.2.271...v2.2.272) (2020-09-16)

## [2.2.271](https://github.com/sprucelabsai/spruce-error/compare/v2.2.270...v2.2.271) (2020-09-16)

## [2.2.270](https://github.com/sprucelabsai/spruce-error/compare/v2.2.269...v2.2.270) (2020-09-16)

## [2.2.269](https://github.com/sprucelabsai/spruce-error/compare/v2.2.268...v2.2.269) (2020-09-15)

## [2.2.268](https://github.com/sprucelabsai/spruce-error/compare/v2.2.267...v2.2.268) (2020-09-15)

## [2.2.267](https://github.com/sprucelabsai/spruce-error/compare/v2.2.266...v2.2.267) (2020-09-15)

## [2.2.266](https://github.com/sprucelabsai/spruce-error/compare/v2.2.265...v2.2.266) (2020-09-15)

## [2.2.265](https://github.com/sprucelabsai/spruce-error/compare/v2.2.264...v2.2.265) (2020-09-15)

## [2.2.264](https://github.com/sprucelabsai/spruce-error/compare/v2.2.263...v2.2.264) (2020-09-15)

## [2.2.263](https://github.com/sprucelabsai/spruce-error/compare/v2.2.262...v2.2.263) (2020-09-15)

## [2.2.262](https://github.com/sprucelabsai/spruce-error/compare/v2.2.261...v2.2.262) (2020-09-14)

## [2.2.261](https://github.com/sprucelabsai/spruce-error/compare/v2.2.260...v2.2.261) (2020-09-14)

## [2.2.260](https://github.com/sprucelabsai/spruce-error/compare/v2.2.259...v2.2.260) (2020-09-14)

## [2.2.259](https://github.com/sprucelabsai/spruce-error/compare/v2.2.258...v2.2.259) (2020-09-14)

## [2.2.258](https://github.com/sprucelabsai/spruce-error/compare/v2.2.257...v2.2.258) (2020-09-14)

## [2.2.257](https://github.com/sprucelabsai/spruce-error/compare/v2.2.256...v2.2.257) (2020-09-13)

## [2.2.256](https://github.com/sprucelabsai/spruce-error/compare/v2.2.255...v2.2.256) (2020-09-13)

## [2.2.255](https://github.com/sprucelabsai/spruce-error/compare/v2.2.254...v2.2.255) (2020-09-13)

## [2.2.254](https://github.com/sprucelabsai/spruce-error/compare/v2.2.253...v2.2.254) (2020-09-13)

## [2.2.253](https://github.com/sprucelabsai/spruce-error/compare/v2.2.252...v2.2.253) (2020-09-13)

## [2.2.252](https://github.com/sprucelabsai/spruce-error/compare/v2.2.251...v2.2.252) (2020-09-13)

## [2.2.251](https://github.com/sprucelabsai/spruce-error/compare/v2.2.250...v2.2.251) (2020-09-13)

## [2.2.250](https://github.com/sprucelabsai/spruce-error/compare/v2.2.249...v2.2.250) (2020-09-13)

## [2.2.249](https://github.com/sprucelabsai/spruce-error/compare/v2.2.248...v2.2.249) (2020-09-13)

## [2.2.248](https://github.com/sprucelabsai/spruce-error/compare/v2.2.247...v2.2.248) (2020-09-13)

## [2.2.247](https://github.com/sprucelabsai/spruce-error/compare/v2.2.246...v2.2.247) (2020-09-13)

## [2.2.246](https://github.com/sprucelabsai/spruce-error/compare/v2.2.245...v2.2.246) (2020-09-12)

## [2.2.245](https://github.com/sprucelabsai/spruce-error/compare/v2.2.244...v2.2.245) (2020-09-12)

## [2.2.244](https://github.com/sprucelabsai/spruce-error/compare/v2.2.243...v2.2.244) (2020-09-12)

## [2.2.243](https://github.com/sprucelabsai/spruce-error/compare/v2.2.242...v2.2.243) (2020-09-12)

## [2.2.242](https://github.com/sprucelabsai/spruce-error/compare/v2.2.241...v2.2.242) (2020-09-12)

## [2.2.241](https://github.com/sprucelabsai/spruce-error/compare/v2.2.240...v2.2.241) (2020-09-12)

## [2.2.240](https://github.com/sprucelabsai/spruce-error/compare/v2.2.239...v2.2.240) (2020-09-11)

## [2.2.239](https://github.com/sprucelabsai/spruce-error/compare/v2.2.238...v2.2.239) (2020-09-11)

## [2.2.238](https://github.com/sprucelabsai/spruce-error/compare/v2.2.237...v2.2.238) (2020-09-11)

## [2.2.237](https://github.com/sprucelabsai/spruce-error/compare/v2.2.236...v2.2.237) (2020-09-11)

## [2.2.236](https://github.com/sprucelabsai/spruce-error/compare/v2.2.235...v2.2.236) (2020-09-11)

## [2.2.235](https://github.com/sprucelabsai/spruce-error/compare/v2.2.234...v2.2.235) (2020-09-11)

## [2.2.234](https://github.com/sprucelabsai/spruce-error/compare/v2.2.233...v2.2.234) (2020-09-11)

## [2.2.233](https://github.com/sprucelabsai/spruce-error/compare/v2.2.232...v2.2.233) (2020-09-10)

## [2.2.232](https://github.com/sprucelabsai/spruce-error/compare/v2.2.231...v2.2.232) (2020-09-10)

## [2.2.231](https://github.com/sprucelabsai/spruce-error/compare/v2.2.230...v2.2.231) (2020-09-10)

## [2.2.230](https://github.com/sprucelabsai/spruce-error/compare/v2.2.229...v2.2.230) (2020-09-10)

## [2.2.229](https://github.com/sprucelabsai/spruce-error/compare/v2.2.228...v2.2.229) (2020-09-10)

## [2.2.228](https://github.com/sprucelabsai/spruce-error/compare/v2.2.227...v2.2.228) (2020-09-10)

## [2.2.227](https://github.com/sprucelabsai/spruce-error/compare/v2.2.226...v2.2.227) (2020-09-10)

## [2.2.226](https://github.com/sprucelabsai/spruce-error/compare/v2.2.225...v2.2.226) (2020-09-10)

## [2.2.225](https://github.com/sprucelabsai/spruce-error/compare/v2.2.224...v2.2.225) (2020-09-10)

## [2.2.224](https://github.com/sprucelabsai/spruce-error/compare/v2.2.223...v2.2.224) (2020-09-09)

## [2.2.223](https://github.com/sprucelabsai/spruce-error/compare/v2.2.222...v2.2.223) (2020-09-09)

## [2.2.222](https://github.com/sprucelabsai/spruce-error/compare/v2.2.221...v2.2.222) (2020-09-09)

## [2.2.221](https://github.com/sprucelabsai/spruce-error/compare/v2.2.220...v2.2.221) (2020-09-09)

## [2.2.220](https://github.com/sprucelabsai/spruce-error/compare/v2.2.219...v2.2.220) (2020-09-09)

## [2.2.219](https://github.com/sprucelabsai/spruce-error/compare/v2.2.218...v2.2.219) (2020-09-09)

## [2.2.218](https://github.com/sprucelabsai/spruce-error/compare/v2.2.217...v2.2.218) (2020-09-09)

## [2.2.217](https://github.com/sprucelabsai/spruce-error/compare/v2.2.216...v2.2.217) (2020-09-09)

## [2.2.216](https://github.com/sprucelabsai/spruce-error/compare/v2.2.215...v2.2.216) (2020-09-08)

## [2.2.215](https://github.com/sprucelabsai/spruce-error/compare/v2.2.214...v2.2.215) (2020-09-08)

## [2.2.214](https://github.com/sprucelabsai/spruce-error/compare/v2.2.213...v2.2.214) (2020-09-08)

## [2.2.213](https://github.com/sprucelabsai/spruce-error/compare/v2.2.212...v2.2.213) (2020-09-08)

## [2.2.212](https://github.com/sprucelabsai/spruce-error/compare/v2.2.211...v2.2.212) (2020-09-07)

## [2.2.211](https://github.com/sprucelabsai/spruce-error/compare/v2.2.210...v2.2.211) (2020-09-07)

## [2.2.210](https://github.com/sprucelabsai/spruce-error/compare/v2.2.209...v2.2.210) (2020-09-07)

## [2.2.209](https://github.com/sprucelabsai/spruce-error/compare/v2.2.208...v2.2.209) (2020-09-07)

## [2.2.208](https://github.com/sprucelabsai/spruce-error/compare/v2.2.207...v2.2.208) (2020-09-06)

## [2.2.207](https://github.com/sprucelabsai/spruce-error/compare/v2.2.206...v2.2.207) (2020-09-06)

## [2.2.206](https://github.com/sprucelabsai/spruce-error/compare/v2.2.205...v2.2.206) (2020-09-06)

## [2.2.205](https://github.com/sprucelabsai/spruce-error/compare/v2.2.204...v2.2.205) (2020-09-06)

## [2.2.204](https://github.com/sprucelabsai/spruce-error/compare/v2.2.203...v2.2.204) (2020-09-06)

## [2.2.203](https://github.com/sprucelabsai/spruce-error/compare/v2.2.202...v2.2.203) (2020-09-06)

## [2.2.202](https://github.com/sprucelabsai/spruce-error/compare/v2.2.201...v2.2.202) (2020-09-06)

## [2.2.201](https://github.com/sprucelabsai/spruce-error/compare/v2.2.200...v2.2.201) (2020-09-05)

## [2.2.200](https://github.com/sprucelabsai/spruce-error/compare/v2.2.199...v2.2.200) (2020-09-05)

## [2.2.199](https://github.com/sprucelabsai/spruce-error/compare/v2.2.198...v2.2.199) (2020-09-04)

## [2.2.198](https://github.com/sprucelabsai/spruce-error/compare/v2.2.197...v2.2.198) (2020-09-04)

## [2.2.197](https://github.com/sprucelabsai/spruce-error/compare/v2.2.196...v2.2.197) (2020-09-04)

## [2.2.196](https://github.com/sprucelabsai/spruce-error/compare/v2.2.195...v2.2.196) (2020-09-04)

## [2.2.195](https://github.com/sprucelabsai/spruce-error/compare/v2.2.194...v2.2.195) (2020-09-04)

## [2.2.194](https://github.com/sprucelabsai/spruce-error/compare/v2.2.193...v2.2.194) (2020-09-04)

## [2.2.193](https://github.com/sprucelabsai/spruce-error/compare/v2.2.192...v2.2.193) (2020-09-04)

## [2.2.192](https://github.com/sprucelabsai/spruce-error/compare/v2.2.191...v2.2.192) (2020-09-04)

## [2.2.191](https://github.com/sprucelabsai/spruce-error/compare/v2.2.190...v2.2.191) (2020-09-03)

## [2.2.190](https://github.com/sprucelabsai/spruce-error/compare/v2.2.189...v2.2.190) (2020-09-03)

## [2.2.189](https://github.com/sprucelabsai/spruce-error/compare/v2.2.188...v2.2.189) (2020-09-03)

## [2.2.188](https://github.com/sprucelabsai/spruce-error/compare/v2.2.187...v2.2.188) (2020-09-03)

## [2.2.187](https://github.com/sprucelabsai/spruce-error/compare/v2.2.186...v2.2.187) (2020-09-03)

## [2.2.186](https://github.com/sprucelabsai/spruce-error/compare/v2.2.185...v2.2.186) (2020-09-03)

## [2.2.185](https://github.com/sprucelabsai/spruce-error/compare/v2.2.184...v2.2.185) (2020-09-03)

## [2.2.184](https://github.com/sprucelabsai/spruce-error/compare/v2.2.183...v2.2.184) (2020-09-03)

## [2.2.183](https://github.com/sprucelabsai/spruce-error/compare/v2.2.182...v2.2.183) (2020-09-03)

## [2.2.182](https://github.com/sprucelabsai/spruce-error/compare/v2.2.181...v2.2.182) (2020-09-03)

## [2.2.181](https://github.com/sprucelabsai/spruce-error/compare/v2.2.180...v2.2.181) (2020-09-03)

## [2.2.180](https://github.com/sprucelabsai/spruce-error/compare/v2.2.179...v2.2.180) (2020-09-03)

## [2.2.179](https://github.com/sprucelabsai/spruce-error/compare/v2.2.178...v2.2.179) (2020-09-03)

## [2.2.178](https://github.com/sprucelabsai/spruce-error/compare/v2.2.177...v2.2.178) (2020-09-02)

## [2.2.177](https://github.com/sprucelabsai/spruce-error/compare/v2.2.176...v2.2.177) (2020-09-02)

## [2.2.176](https://github.com/sprucelabsai/spruce-error/compare/v2.2.175...v2.2.176) (2020-09-02)

## [2.2.175](https://github.com/sprucelabsai/spruce-error/compare/v2.2.174...v2.2.175) (2020-09-02)

## [2.2.174](https://github.com/sprucelabsai/spruce-error/compare/v2.2.173...v2.2.174) (2020-09-02)

## [2.2.173](https://github.com/sprucelabsai/spruce-error/compare/v2.2.172...v2.2.173) (2020-09-02)

## [2.2.172](https://github.com/sprucelabsai/spruce-error/compare/v2.2.171...v2.2.172) (2020-09-01)

## [2.2.171](https://github.com/sprucelabsai/spruce-error/compare/v2.2.170...v2.2.171) (2020-09-01)

## [2.2.170](https://github.com/sprucelabsai/spruce-error/compare/v2.2.169...v2.2.170) (2020-09-01)

## [2.2.169](https://github.com/sprucelabsai/spruce-error/compare/v2.2.168...v2.2.169) (2020-09-01)

## [2.2.168](https://github.com/sprucelabsai/spruce-error/compare/v2.2.167...v2.2.168) (2020-09-01)

## [2.2.167](https://github.com/sprucelabsai/spruce-error/compare/v2.2.166...v2.2.167) (2020-09-01)

## [2.2.166](https://github.com/sprucelabsai/spruce-error/compare/v2.2.165...v2.2.166) (2020-09-01)

## [2.2.165](https://github.com/sprucelabsai/spruce-error/compare/v2.2.164...v2.2.165) (2020-09-01)

## [2.2.164](https://github.com/sprucelabsai/spruce-error/compare/v2.2.163...v2.2.164) (2020-09-01)

## [2.2.163](https://github.com/sprucelabsai/spruce-error/compare/v2.2.162...v2.2.163) (2020-09-01)

## [2.2.162](https://github.com/sprucelabsai/spruce-error/compare/v2.2.161...v2.2.162) (2020-09-01)

## [2.2.161](https://github.com/sprucelabsai/spruce-error/compare/v2.2.160...v2.2.161) (2020-08-31)

## [2.2.160](https://github.com/sprucelabsai/spruce-error/compare/v2.2.159...v2.2.160) (2020-08-31)

## [2.2.159](https://github.com/sprucelabsai/spruce-error/compare/v2.2.158...v2.2.159) (2020-08-31)

## [2.2.158](https://github.com/sprucelabsai/spruce-error/compare/v2.2.157...v2.2.158) (2020-08-31)

## [2.2.157](https://github.com/sprucelabsai/spruce-error/compare/v2.2.156...v2.2.157) (2020-08-31)

## [2.2.156](https://github.com/sprucelabsai/spruce-error/compare/v2.2.155...v2.2.156) (2020-08-31)

## [2.2.155](https://github.com/sprucelabsai/spruce-error/compare/v2.2.154...v2.2.155) (2020-08-31)

## [2.2.154](https://github.com/sprucelabsai/spruce-error/compare/v2.2.153...v2.2.154) (2020-08-31)

## [2.2.153](https://github.com/sprucelabsai/spruce-error/compare/v2.2.152...v2.2.153) (2020-08-30)

## [2.2.152](https://github.com/sprucelabsai/spruce-error/compare/v2.2.151...v2.2.152) (2020-08-30)

## [2.2.151](https://github.com/sprucelabsai/spruce-error/compare/v2.2.150...v2.2.151) (2020-08-30)

## [2.2.150](https://github.com/sprucelabsai/spruce-error/compare/v2.2.149...v2.2.150) (2020-08-30)

## [2.2.149](https://github.com/sprucelabsai/spruce-error/compare/v2.2.148...v2.2.149) (2020-08-30)

## [2.2.148](https://github.com/sprucelabsai/spruce-error/compare/v2.2.147...v2.2.148) (2020-08-30)

## [2.2.147](https://github.com/sprucelabsai/spruce-error/compare/v2.2.146...v2.2.147) (2020-08-30)

## [2.2.146](https://github.com/sprucelabsai/spruce-error/compare/v2.2.145...v2.2.146) (2020-08-30)

## [2.2.145](https://github.com/sprucelabsai/spruce-error/compare/v2.2.144...v2.2.145) (2020-08-30)

## [2.2.144](https://github.com/sprucelabsai/spruce-error/compare/v2.2.143...v2.2.144) (2020-08-29)

## [2.2.143](https://github.com/sprucelabsai/spruce-error/compare/v2.2.142...v2.2.143) (2020-08-29)

## [2.2.142](https://github.com/sprucelabsai/spruce-error/compare/v2.2.141...v2.2.142) (2020-08-29)

## [2.2.141](https://github.com/sprucelabsai/spruce-error/compare/v2.2.140...v2.2.141) (2020-08-29)

## [2.2.140](https://github.com/sprucelabsai/spruce-error/compare/v2.2.139...v2.2.140) (2020-08-29)

## [2.2.139](https://github.com/sprucelabsai/spruce-error/compare/v2.2.138...v2.2.139) (2020-08-29)

## [2.2.138](https://github.com/sprucelabsai/spruce-error/compare/v2.2.137...v2.2.138) (2020-08-29)

## [2.2.137](https://github.com/sprucelabsai/spruce-error/compare/v2.2.136...v2.2.137) (2020-08-29)

## [2.2.136](https://github.com/sprucelabsai/spruce-error/compare/v2.2.135...v2.2.136) (2020-08-29)

## [2.2.135](https://github.com/sprucelabsai/spruce-error/compare/v2.2.134...v2.2.135) (2020-08-29)

## [2.2.134](https://github.com/sprucelabsai/spruce-error/compare/v2.2.133...v2.2.134) (2020-08-29)

## [2.2.133](https://github.com/sprucelabsai/spruce-error/compare/v2.2.132...v2.2.133) (2020-08-28)

## [2.2.132](https://github.com/sprucelabsai/spruce-error/compare/v2.2.131...v2.2.132) (2020-08-28)

## [2.2.131](https://github.com/sprucelabsai/spruce-error/compare/v2.2.130...v2.2.131) (2020-08-28)

## [2.2.130](https://github.com/sprucelabsai/spruce-error/compare/v2.2.129...v2.2.130) (2020-08-28)

## [2.2.129](https://github.com/sprucelabsai/spruce-error/compare/v2.2.128...v2.2.129) (2020-08-28)

## [2.2.128](https://github.com/sprucelabsai/spruce-error/compare/v2.2.127...v2.2.128) (2020-08-28)

## [2.2.127](https://github.com/sprucelabsai/spruce-error/compare/v2.2.126...v2.2.127) (2020-08-28)

## [2.2.126](https://github.com/sprucelabsai/spruce-error/compare/v2.2.125...v2.2.126) (2020-08-28)

## [2.2.125](https://github.com/sprucelabsai/spruce-error/compare/v2.2.124...v2.2.125) (2020-08-28)

## [2.2.124](https://github.com/sprucelabsai/spruce-error/compare/v2.2.123...v2.2.124) (2020-08-28)

## [2.2.123](https://github.com/sprucelabsai/spruce-error/compare/v2.2.122...v2.2.123) (2020-08-28)

## [2.2.122](https://github.com/sprucelabsai/spruce-error/compare/v2.2.121...v2.2.122) (2020-08-27)

## [2.2.121](https://github.com/sprucelabsai/spruce-error/compare/v2.2.120...v2.2.121) (2020-08-27)

## [2.2.120](https://github.com/sprucelabsai/spruce-error/compare/v2.2.119...v2.2.120) (2020-08-27)

## [2.2.119](https://github.com/sprucelabsai/spruce-error/compare/v2.2.118...v2.2.119) (2020-08-27)

## [2.2.118](https://github.com/sprucelabsai/spruce-error/compare/v2.2.117...v2.2.118) (2020-08-27)

## [2.2.117](https://github.com/sprucelabsai/spruce-error/compare/v2.2.116...v2.2.117) (2020-08-27)

## [2.2.116](https://github.com/sprucelabsai/spruce-error/compare/v2.2.115...v2.2.116) (2020-08-27)

## [2.2.115](https://github.com/sprucelabsai/spruce-error/compare/v2.2.114...v2.2.115) (2020-08-27)

## [2.2.114](https://github.com/sprucelabsai/spruce-error/compare/v2.2.113...v2.2.114) (2020-08-27)

## [2.2.113](https://github.com/sprucelabsai/spruce-error/compare/v2.2.112...v2.2.113) (2020-08-27)

## [2.2.112](https://github.com/sprucelabsai/spruce-error/compare/v2.2.111...v2.2.112) (2020-08-27)

## [2.2.111](https://github.com/sprucelabsai/spruce-error/compare/v2.2.110...v2.2.111) (2020-08-27)

## [2.2.110](https://github.com/sprucelabsai/spruce-error/compare/v2.2.109...v2.2.110) (2020-08-27)

## [2.2.109](https://github.com/sprucelabsai/spruce-error/compare/v2.2.108...v2.2.109) (2020-08-26)

## [2.2.108](https://github.com/sprucelabsai/spruce-error/compare/v2.2.107...v2.2.108) (2020-08-26)

## [2.2.107](https://github.com/sprucelabsai/spruce-error/compare/v2.2.106...v2.2.107) (2020-08-26)

## [2.2.106](https://github.com/sprucelabsai/spruce-error/compare/v2.2.105...v2.2.106) (2020-08-26)

## [2.2.105](https://github.com/sprucelabsai/spruce-error/compare/v2.2.104...v2.2.105) (2020-08-26)

## [2.2.104](https://github.com/sprucelabsai/spruce-error/compare/v2.2.103...v2.2.104) (2020-08-26)

## [2.2.103](https://github.com/sprucelabsai/spruce-error/compare/v2.2.102...v2.2.103) (2020-08-26)

## [2.2.102](https://github.com/sprucelabsai/spruce-error/compare/v2.2.101...v2.2.102) (2020-08-26)

## [2.2.101](https://github.com/sprucelabsai/spruce-error/compare/v2.2.100...v2.2.101) (2020-08-26)

## [2.2.100](https://github.com/sprucelabsai/spruce-error/compare/v2.2.99...v2.2.100) (2020-08-26)

## [2.2.99](https://github.com/sprucelabsai/spruce-error/compare/v2.2.98...v2.2.99) (2020-08-26)

## [2.2.98](https://github.com/sprucelabsai/spruce-error/compare/v2.2.97...v2.2.98) (2020-08-26)

## [2.2.97](https://github.com/sprucelabsai/spruce-error/compare/v2.2.96...v2.2.97) (2020-08-26)

## [2.2.96](https://github.com/sprucelabsai/spruce-error/compare/v2.2.95...v2.2.96) (2020-08-25)

## [2.2.95](https://github.com/sprucelabsai/spruce-error/compare/v2.2.94...v2.2.95) (2020-08-25)

## [2.2.94](https://github.com/sprucelabsai/spruce-error/compare/v2.2.93...v2.2.94) (2020-08-25)

## [2.2.93](https://github.com/sprucelabsai/spruce-error/compare/v2.2.92...v2.2.93) (2020-08-25)

## [2.2.92](https://github.com/sprucelabsai/spruce-error/compare/v2.2.91...v2.2.92) (2020-08-25)

## [2.2.91](https://github.com/sprucelabsai/spruce-error/compare/v2.2.90...v2.2.91) (2020-08-25)

## [2.2.90](https://github.com/sprucelabsai/spruce-error/compare/v2.2.89...v2.2.90) (2020-08-25)

## [2.2.89](https://github.com/sprucelabsai/spruce-error/compare/v2.2.88...v2.2.89) (2020-08-25)

## [2.2.88](https://github.com/sprucelabsai/spruce-error/compare/v2.2.87...v2.2.88) (2020-08-25)

## [2.2.87](https://github.com/sprucelabsai/spruce-error/compare/v2.2.86...v2.2.87) (2020-08-25)

## [2.2.86](https://github.com/sprucelabsai/spruce-error/compare/v2.2.85...v2.2.86) (2020-08-25)

## [2.2.85](https://github.com/sprucelabsai/spruce-error/compare/v2.2.84...v2.2.85) (2020-08-24)

## [2.2.84](https://github.com/sprucelabsai/spruce-error/compare/v2.2.83...v2.2.84) (2020-08-24)

## [2.2.83](https://github.com/sprucelabsai/spruce-error/compare/v2.2.82...v2.2.83) (2020-08-24)

## [2.2.82](https://github.com/sprucelabsai/spruce-error/compare/v2.2.81...v2.2.82) (2020-08-24)

## [2.2.81](https://github.com/sprucelabsai/spruce-error/compare/v2.2.80...v2.2.81) (2020-08-24)

## [2.2.80](https://github.com/sprucelabsai/spruce-error/compare/v2.2.79...v2.2.80) (2020-08-24)

## [2.2.79](https://github.com/sprucelabsai/spruce-error/compare/v2.2.78...v2.2.79) (2020-08-23)

## [2.2.78](https://github.com/sprucelabsai/spruce-error/compare/v2.2.77...v2.2.78) (2020-08-23)

## [2.2.77](https://github.com/sprucelabsai/spruce-error/compare/v2.2.76...v2.2.77) (2020-08-23)

## [2.2.76](https://github.com/sprucelabsai/spruce-error/compare/v2.2.75...v2.2.76) (2020-08-23)

## [2.2.75](https://github.com/sprucelabsai/spruce-error/compare/v2.2.74...v2.2.75) (2020-08-23)

## [2.2.74](https://github.com/sprucelabsai/spruce-error/compare/v2.2.73...v2.2.74) (2020-08-23)

## [2.2.73](https://github.com/sprucelabsai/spruce-error/compare/v2.2.72...v2.2.73) (2020-08-23)

## [2.2.72](https://github.com/sprucelabsai/spruce-error/compare/v2.2.71...v2.2.72) (2020-08-23)

## [2.2.71](https://github.com/sprucelabsai/spruce-error/compare/v2.2.70...v2.2.71) (2020-08-22)

## [2.2.70](https://github.com/sprucelabsai/spruce-error/compare/v2.2.69...v2.2.70) (2020-08-22)

## [2.2.69](https://github.com/sprucelabsai/spruce-error/compare/v2.2.68...v2.2.69) (2020-08-22)

## [2.2.68](https://github.com/sprucelabsai/spruce-error/compare/v2.2.67...v2.2.68) (2020-08-22)

## [2.2.67](https://github.com/sprucelabsai/spruce-error/compare/v2.2.66...v2.2.67) (2020-08-22)

## [2.2.66](https://github.com/sprucelabsai/spruce-error/compare/v2.2.65...v2.2.66) (2020-08-22)

## [2.2.65](https://github.com/sprucelabsai/spruce-error/compare/v2.2.64...v2.2.65) (2020-08-22)

## [2.2.64](https://github.com/sprucelabsai/spruce-error/compare/v2.2.63...v2.2.64) (2020-08-22)

## [2.2.63](https://github.com/sprucelabsai/spruce-error/compare/v2.2.62...v2.2.63) (2020-08-22)

## [2.2.62](https://github.com/sprucelabsai/spruce-error/compare/v2.2.61...v2.2.62) (2020-08-22)

## [2.2.61](https://github.com/sprucelabsai/spruce-error/compare/v2.2.60...v2.2.61) (2020-08-21)

## [2.2.60](https://github.com/sprucelabsai/spruce-error/compare/v2.2.59...v2.2.60) (2020-08-21)

## [2.2.59](https://github.com/sprucelabsai/spruce-error/compare/v2.2.58...v2.2.59) (2020-08-21)

## [2.2.58](https://github.com/sprucelabsai/spruce-error/compare/v2.2.57...v2.2.58) (2020-08-21)

## [2.2.57](https://github.com/sprucelabsai/spruce-error/compare/v2.2.56...v2.2.57) (2020-08-21)

## [2.2.56](https://github.com/sprucelabsai/spruce-error/compare/v2.2.55...v2.2.56) (2020-08-21)

## [2.2.55](https://github.com/sprucelabsai/spruce-error/compare/v2.2.54...v2.2.55) (2020-08-21)

## [2.2.54](https://github.com/sprucelabsai/spruce-error/compare/v2.2.53...v2.2.54) (2020-08-21)

## [2.2.53](https://github.com/sprucelabsai/spruce-error/compare/v2.2.52...v2.2.53) (2020-08-20)

## [2.2.52](https://github.com/sprucelabsai/spruce-error/compare/v2.2.51...v2.2.52) (2020-08-20)

## [2.2.51](https://github.com/sprucelabsai/spruce-error/compare/v2.2.50...v2.2.51) (2020-08-20)

## [2.2.50](https://github.com/sprucelabsai/spruce-error/compare/v2.2.49...v2.2.50) (2020-08-20)

## [2.2.49](https://github.com/sprucelabsai/spruce-error/compare/v2.2.48...v2.2.49) (2020-08-20)

## [2.2.48](https://github.com/sprucelabsai/spruce-error/compare/v2.2.47...v2.2.48) (2020-08-20)

## [2.2.47](https://github.com/sprucelabsai/spruce-error/compare/v2.2.46...v2.2.47) (2020-08-20)

## [2.2.46](https://github.com/sprucelabsai/spruce-error/compare/v2.2.45...v2.2.46) (2020-08-20)

## [2.2.45](https://github.com/sprucelabsai/spruce-error/compare/v2.2.44...v2.2.45) (2020-08-20)

## [2.2.44](https://github.com/sprucelabsai/spruce-error/compare/v2.2.43...v2.2.44) (2020-08-19)

## [2.2.43](https://github.com/sprucelabsai/spruce-error/compare/v2.2.42...v2.2.43) (2020-08-19)

## [2.2.42](https://github.com/sprucelabsai/spruce-error/compare/v2.2.41...v2.2.42) (2020-08-19)

## [2.2.41](https://github.com/sprucelabsai/spruce-error/compare/v2.2.40...v2.2.41) (2020-08-19)

## [2.2.40](https://github.com/sprucelabsai/spruce-error/compare/v2.2.39...v2.2.40) (2020-08-19)

## [2.2.39](https://github.com/sprucelabsai/spruce-error/compare/v2.2.38...v2.2.39) (2020-08-19)

## [2.2.38](https://github.com/sprucelabsai/spruce-error/compare/v2.2.37...v2.2.38) (2020-08-18)

## [2.2.37](https://github.com/sprucelabsai/spruce-error/compare/v2.2.36...v2.2.37) (2020-08-18)

## [2.2.36](https://github.com/sprucelabsai/spruce-error/compare/v2.2.35...v2.2.36) (2020-08-18)

## [2.2.35](https://github.com/sprucelabsai/spruce-error/compare/v2.2.34...v2.2.35) (2020-08-18)

## [2.2.34](https://github.com/sprucelabsai/spruce-error/compare/v2.2.33...v2.2.34) (2020-08-18)

## [2.2.33](https://github.com/sprucelabsai/spruce-error/compare/v2.2.32...v2.2.33) (2020-08-18)

## [2.2.32](https://github.com/sprucelabsai/spruce-error/compare/v2.2.31...v2.2.32) (2020-08-18)

## [2.2.31](https://github.com/sprucelabsai/spruce-error/compare/v2.2.30...v2.2.31) (2020-08-18)

## [2.2.30](https://github.com/sprucelabsai/spruce-error/compare/v2.2.29...v2.2.30) (2020-08-17)

## [2.2.29](https://github.com/sprucelabsai/spruce-error/compare/v2.2.28...v2.2.29) (2020-08-17)

## [2.2.28](https://github.com/sprucelabsai/spruce-error/compare/v2.2.27...v2.2.28) (2020-08-17)

## [2.2.27](https://github.com/sprucelabsai/spruce-error/compare/v2.2.26...v2.2.27) (2020-08-17)

## [2.2.26](https://github.com/sprucelabsai/spruce-error/compare/v2.2.25...v2.2.26) (2020-08-17)

## [2.2.25](https://github.com/sprucelabsai/spruce-error/compare/v2.2.24...v2.2.25) (2020-08-17)

## [2.2.24](https://github.com/sprucelabsai/spruce-error/compare/v2.2.23...v2.2.24) (2020-08-17)

## [2.2.23](https://github.com/sprucelabsai/spruce-error/compare/v2.2.22...v2.2.23) (2020-08-17)

## [2.2.22](https://github.com/sprucelabsai/spruce-error/compare/v2.2.21...v2.2.22) (2020-08-16)

## [2.2.21](https://github.com/sprucelabsai/spruce-error/compare/v2.2.20...v2.2.21) (2020-08-16)

## [2.2.20](https://github.com/sprucelabsai/spruce-error/compare/v2.2.19...v2.2.20) (2020-08-16)

## [2.2.19](https://github.com/sprucelabsai/spruce-error/compare/v2.2.18...v2.2.19) (2020-08-16)

## [2.2.18](https://github.com/sprucelabsai/spruce-error/compare/v2.2.17...v2.2.18) (2020-08-16)

## [2.2.17](https://github.com/sprucelabsai/spruce-error/compare/v2.2.16...v2.2.17) (2020-08-15)

## [2.2.16](https://github.com/sprucelabsai/spruce-error/compare/v2.2.15...v2.2.16) (2020-08-15)

## [2.2.15](https://github.com/sprucelabsai/spruce-error/compare/v2.2.14...v2.2.15) (2020-08-15)

## [2.2.14](https://github.com/sprucelabsai/spruce-error/compare/v2.2.13...v2.2.14) (2020-08-15)

## [2.2.13](https://github.com/sprucelabsai/spruce-error/compare/v2.2.12...v2.2.13) (2020-08-14)

## [2.2.12](https://github.com/sprucelabsai/spruce-error/compare/v2.2.11...v2.2.12) (2020-08-14)

## [2.2.11](https://github.com/sprucelabsai/spruce-error/compare/v2.2.10...v2.2.11) (2020-08-14)

## [2.2.10](https://github.com/sprucelabsai/spruce-error/compare/v2.2.9...v2.2.10) (2020-08-14)

## [2.2.9](https://github.com/sprucelabsai/spruce-error/compare/v2.2.8...v2.2.9) (2020-08-14)

## [2.2.8](https://github.com/sprucelabsai/spruce-error/compare/v2.2.7...v2.2.8) (2020-08-14)

## [2.2.7](https://github.com/sprucelabsai/spruce-error/compare/v2.2.6...v2.2.7) (2020-08-14)

## [2.2.6](https://github.com/sprucelabsai/spruce-error/compare/v2.2.5...v2.2.6) (2020-08-14)

## [2.2.5](https://github.com/sprucelabsai/spruce-error/compare/v2.2.4...v2.2.5) (2020-08-14)

## [2.2.4](https://github.com/sprucelabsai/spruce-error/compare/v2.2.3...v2.2.4) (2020-08-14)

## [2.2.3](https://github.com/sprucelabsai/spruce-error/compare/v2.2.2...v2.2.3) (2020-08-14)

## [2.2.2](https://github.com/sprucelabsai/spruce-error/compare/v2.2.1...v2.2.2) (2020-08-14)

## [2.2.1](https://github.com/sprucelabsai/spruce-error/compare/v2.2.0...v2.2.1) (2020-08-13)

# [2.2.0](https://github.com/sprucelabsai/spruce-error/compare/v2.1.4...v2.2.0) (2020-08-13)


### Features

* handle failed error parse ([d6cad31](https://github.com/sprucelabsai/spruce-error/commit/d6cad31))

## [2.1.4](https://github.com/sprucelabsai/spruce-error/compare/v2.1.3...v2.1.4) (2020-08-13)

## [2.1.3](https://github.com/sprucelabsai/spruce-error/compare/v2.1.2...v2.1.3) (2020-08-13)

## [2.1.2](https://github.com/sprucelabsai/spruce-error/compare/v2.1.1...v2.1.2) (2020-08-13)

## [2.1.1](https://github.com/sprucelabsai/spruce-error/compare/v2.1.0...v2.1.1) (2020-08-13)

# [2.1.0](https://github.com/sprucelabsai/spruce-error/compare/v2.0.62...v2.1.0) (2020-08-13)


### Features

* build before lint ([fff6520](https://github.com/sprucelabsai/spruce-error/commit/fff6520))

## [2.0.62](https://github.com/sprucelabsai/spruce-error/compare/v2.0.61...v2.0.62) (2020-08-13)

## [2.0.61](https://github.com/sprucelabsai/spruce-error/compare/v2.0.60...v2.0.61) (2020-08-13)

## [2.0.60](https://github.com/sprucelabsai/spruce-error/compare/v2.0.59...v2.0.60) (2020-08-13)

## [2.0.59](https://github.com/sprucelabsai/spruce-error/compare/v2.0.58...v2.0.59) (2020-08-12)

## [2.0.58](https://github.com/sprucelabsai/spruce-error/compare/v2.0.57...v2.0.58) (2020-08-12)

## [2.0.57](https://github.com/sprucelabsai/spruce-error/compare/v2.0.56...v2.0.57) (2020-08-12)

## [2.0.56](https://github.com/sprucelabsai/spruce-error/compare/v2.0.55...v2.0.56) (2020-08-12)

## [2.0.55](https://github.com/sprucelabsai/spruce-error/compare/v2.0.54...v2.0.55) (2020-08-11)

## [2.0.54](https://github.com/sprucelabsai/spruce-error/compare/v2.0.53...v2.0.54) (2020-08-11)

## [2.0.53](https://github.com/sprucelabsai/spruce-error/compare/v2.0.52...v2.0.53) (2020-08-11)

## [2.0.52](https://github.com/sprucelabsai/spruce-error/compare/v2.0.51...v2.0.52) (2020-08-11)

## [2.0.51](https://github.com/sprucelabsai/spruce-error/compare/v2.0.50...v2.0.51) (2020-08-11)

## [2.0.50](https://github.com/sprucelabsai/spruce-error/compare/v2.0.49...v2.0.50) (2020-08-11)

## [2.0.49](https://github.com/sprucelabsai/spruce-error/compare/v2.0.48...v2.0.49) (2020-08-10)

## [2.0.48](https://github.com/sprucelabsai/spruce-error/compare/v2.0.47...v2.0.48) (2020-08-10)

## [2.0.47](https://github.com/sprucelabsai/spruce-error/compare/v2.0.46...v2.0.47) (2020-08-10)

## [2.0.46](https://github.com/sprucelabsai/spruce-error/compare/v2.0.45...v2.0.46) (2020-08-10)


### Bug Fixes

* build.node tsc should fail if it fails ([201140f](https://github.com/sprucelabsai/spruce-error/commit/201140f))

## [2.0.45](https://github.com/sprucelabsai/spruce-error/compare/v2.0.44...v2.0.45) (2020-08-10)

## [2.0.44](https://github.com/sprucelabsai/spruce-error/compare/v2.0.43...v2.0.44) (2020-08-10)

## [2.0.43](https://github.com/sprucelabsai/spruce-error/compare/v2.0.42...v2.0.43) (2020-08-09)

## [2.0.42](https://github.com/sprucelabsai/spruce-error/compare/v2.0.41...v2.0.42) (2020-08-09)

## [2.0.41](https://github.com/sprucelabsai/spruce-error/compare/v2.0.40...v2.0.41) (2020-08-09)

## [2.0.40](https://github.com/sprucelabsai/spruce-error/compare/v2.0.39...v2.0.40) (2020-08-09)

## [2.0.39](https://github.com/sprucelabsai/spruce-error/compare/v2.0.38...v2.0.39) (2020-08-09)

## [2.0.38](https://github.com/sprucelabsai/spruce-error/compare/v2.0.37...v2.0.38) (2020-08-09)

## [2.0.37](https://github.com/sprucelabsai/spruce-error/compare/v2.0.36...v2.0.37) (2020-08-08)

## [2.0.36](https://github.com/sprucelabsai/spruce-error/compare/v2.0.35...v2.0.36) (2020-08-08)

## [2.0.35](https://github.com/sprucelabsai/spruce-error/compare/v2.0.34...v2.0.35) (2020-08-08)

## [2.0.34](https://github.com/sprucelabsai/spruce-error/compare/v2.0.33...v2.0.34) (2020-08-08)

## [2.0.33](https://github.com/sprucelabsai/spruce-error/compare/v2.0.32...v2.0.33) (2020-08-07)

## [2.0.32](https://github.com/sprucelabsai/spruce-error/compare/v2.0.31...v2.0.32) (2020-08-07)

## [2.0.31](https://github.com/sprucelabsai/spruce-error/compare/v2.0.30...v2.0.31) (2020-08-06)

## [2.0.30](https://github.com/sprucelabsai/spruce-error/compare/v2.0.29...v2.0.30) (2020-08-05)

## [2.0.29](https://github.com/sprucelabsai/spruce-error/compare/v2.0.28...v2.0.29) (2020-08-05)

## [2.0.28](https://github.com/sprucelabsai/spruce-error/compare/v2.0.27...v2.0.28) (2020-08-05)

## [2.0.27](https://github.com/sprucelabsai/spruce-error/compare/v2.0.26...v2.0.27) (2020-08-04)

## [2.0.26](https://github.com/sprucelabsai/spruce-error/compare/v2.0.25...v2.0.26) (2020-08-04)

## [2.0.25](https://github.com/sprucelabsai/spruce-error/compare/v2.0.24...v2.0.25) (2020-08-04)

## [2.0.24](https://github.com/sprucelabsai/spruce-error/compare/v2.0.23...v2.0.24) (2020-08-04)

## [2.0.23](https://github.com/sprucelabsai/spruce-error/compare/v2.0.22...v2.0.23) (2020-08-04)

## [2.0.22](https://github.com/sprucelabsai/spruce-error/compare/v2.0.21...v2.0.22) (2020-08-04)

## [2.0.21](https://github.com/sprucelabsai/spruce-error/compare/v2.0.20...v2.0.21) (2020-08-03)

## [2.0.20](https://github.com/sprucelabsai/spruce-error/compare/v2.0.19...v2.0.20) (2020-08-03)

## [2.0.19](https://github.com/sprucelabsai/spruce-error/compare/v2.0.18...v2.0.19) (2020-08-02)

## [2.0.18](https://github.com/sprucelabsai/spruce-error/compare/v2.0.17...v2.0.18) (2020-08-02)

## [2.0.17](https://github.com/sprucelabsai/spruce-error/compare/v2.0.16...v2.0.17) (2020-08-02)

## [2.0.16](https://github.com/sprucelabsai/spruce-error/compare/v2.0.15...v2.0.16) (2020-08-01)

## [2.0.15](https://github.com/sprucelabsai/spruce-error/compare/v2.0.14...v2.0.15) (2020-07-31)

## [2.0.14](https://github.com/sprucelabsai/spruce-error/compare/v2.0.13...v2.0.14) (2020-07-31)

## [2.0.13](https://github.com/sprucelabsai/spruce-error/compare/v2.0.12...v2.0.13) (2020-07-31)

## [2.0.12](https://github.com/sprucelabsai/spruce-error/compare/v2.0.11...v2.0.12) (2020-07-30)

## [2.0.11](https://github.com/sprucelabsai/spruce-error/compare/v2.0.10...v2.0.11) (2020-07-30)

## [2.0.10](https://github.com/sprucelabsai/spruce-error/compare/v2.0.9...v2.0.10) (2020-07-30)

## [2.0.9](https://github.com/sprucelabsai/spruce-error/compare/v2.0.8...v2.0.9) (2020-07-30)

## [2.0.8](https://github.com/sprucelabsai/spruce-error/compare/v2.0.7...v2.0.8) (2020-07-30)

## [2.0.7](https://github.com/sprucelabsai/spruce-error/compare/v2.0.6...v2.0.7) (2020-07-29)

## [2.0.6](https://github.com/sprucelabsai/spruce-error/compare/v2.0.5...v2.0.6) (2020-07-28)

## [2.0.5](https://github.com/sprucelabsai/spruce-error/compare/v2.0.4...v2.0.5) (2020-07-28)

## [2.0.4](https://github.com/sprucelabsai/spruce-error/compare/v2.0.3...v2.0.4) (2020-07-28)

## [2.0.3](https://github.com/sprucelabsai/spruce-error/compare/v2.0.2...v2.0.3) (2020-07-28)

## [2.0.2](https://github.com/sprucelabsai/spruce-error/compare/v2.0.1...v2.0.2) (2020-07-27)

## [2.0.1](https://github.com/sprucelabsai/spruce-error/compare/v2.0.0...v2.0.1) (2020-07-27)

# [2.0.0](https://github.com/sprucelabsai/spruce-error/compare/v1.3.46...v2.0.0) (2020-07-27)


### Breaking Changes

* drop enum ([165692c](https://github.com/sprucelabsai/spruce-error/commit/165692c))

## [1.3.46](https://github.com/sprucelabsai/spruce-error/compare/v1.3.45...v1.3.46) (2020-07-27)

## [1.3.45](https://github.com/sprucelabsai/spruce-error/compare/v1.3.44...v1.3.45) (2020-07-24)

## [1.3.44](https://github.com/sprucelabsai/spruce-error/compare/v1.3.43...v1.3.44) (2020-07-24)

## [1.3.43](https://github.com/sprucelabsai/spruce-error/compare/v1.3.42...v1.3.43) (2020-07-24)

## [1.3.42](https://github.com/sprucelabsai/spruce-error/compare/v1.3.41...v1.3.42) (2020-07-24)

## [1.3.41](https://github.com/sprucelabsai/spruce-error/compare/v1.3.40...v1.3.41) (2020-07-24)

## [1.3.40](https://github.com/sprucelabsai/spruce-error/compare/v1.3.39...v1.3.40) (2020-07-24)

## [1.3.39](https://github.com/sprucelabsai/spruce-error/compare/v1.3.38...v1.3.39) (2020-07-23)

## [1.3.38](https://github.com/sprucelabsai/spruce-error/compare/v1.3.37...v1.3.38) (2020-07-23)

## [1.3.37](https://github.com/sprucelabsai/spruce-error/compare/v1.3.36...v1.3.37) (2020-07-23)

## [1.3.36](https://github.com/sprucelabsai/spruce-error/compare/v1.3.35...v1.3.36) (2020-07-23)

## [1.3.35](https://github.com/sprucelabsai/spruce-error/compare/v1.3.34...v1.3.35) (2020-07-23)

## [1.3.34](https://github.com/sprucelabsai/spruce-error/compare/v1.3.33...v1.3.34) (2020-07-23)

## [1.3.33](https://github.com/sprucelabsai/spruce-error/compare/v1.3.32...v1.3.33) (2020-07-23)

## [1.3.32](https://github.com/sprucelabsai/spruce-error/compare/v1.3.31...v1.3.32) (2020-07-22)

## [1.3.31](https://github.com/sprucelabsai/spruce-error/compare/v1.3.30...v1.3.31) (2020-07-22)

## [1.3.30](https://github.com/sprucelabsai/spruce-error/compare/v1.3.29...v1.3.30) (2020-07-22)

## [1.3.29](https://github.com/sprucelabsai/spruce-error/compare/v1.3.28...v1.3.29) (2020-07-22)

## [1.3.28](https://github.com/sprucelabsai/spruce-error/compare/v1.3.27...v1.3.28) (2020-07-22)

## [1.3.27](https://github.com/sprucelabsai/spruce-error/compare/v1.3.26...v1.3.27) (2020-07-22)

## [1.3.26](https://github.com/sprucelabsai/spruce-error/compare/v1.3.25...v1.3.26) (2020-07-22)

## [1.3.25](https://github.com/sprucelabsai/spruce-error/compare/v1.3.24...v1.3.25) (2020-07-22)

## [1.3.24](https://github.com/sprucelabsai/spruce-error/compare/v1.3.23...v1.3.24) (2020-07-21)

## [1.3.23](https://github.com/sprucelabsai/spruce-error/compare/v1.3.22...v1.3.23) (2020-07-21)

## [1.3.22](https://github.com/sprucelabsai/spruce-error/compare/v1.3.21...v1.3.22) (2020-07-20)

## [1.3.21](https://github.com/sprucelabsai/spruce-error/compare/v1.3.20...v1.3.21) (2020-07-20)

## [1.3.20](https://github.com/sprucelabsai/spruce-error/compare/v1.3.19...v1.3.20) (2020-07-19)

## [1.3.19](https://github.com/sprucelabsai/spruce-error/compare/v1.3.18...v1.3.19) (2020-07-18)

## [1.3.18](https://github.com/sprucelabsai/spruce-error/compare/v1.3.17...v1.3.18) (2020-07-17)

## [1.3.17](https://github.com/sprucelabsai/spruce-error/compare/v1.3.16...v1.3.17) (2020-07-17)

## [1.3.16](https://github.com/sprucelabsai/spruce-error/compare/v1.3.15...v1.3.16) (2020-07-17)

## [1.3.15](https://github.com/sprucelabsai/spruce-error/compare/v1.3.14...v1.3.15) (2020-07-16)

## [1.3.14](https://github.com/sprucelabsai/spruce-error/compare/v1.3.13...v1.3.14) (2020-07-16)

## [1.3.13](https://github.com/sprucelabsai/spruce-error/compare/v1.3.12...v1.3.13) (2020-07-16)

## [1.3.12](https://github.com/sprucelabsai/spruce-error/compare/v1.3.11...v1.3.12) (2020-07-14)

## [1.3.11](https://github.com/sprucelabsai/spruce-error/compare/v1.3.10...v1.3.11) (2020-07-14)

## [1.3.10](https://github.com/sprucelabsai/spruce-error/compare/v1.3.9...v1.3.10) (2020-07-14)

## [1.3.9](https://github.com/sprucelabsai/spruce-error/compare/v1.3.8...v1.3.9) (2020-07-09)

## [1.3.8](https://github.com/sprucelabsai/spruce-error/compare/v1.3.7...v1.3.8) (2020-07-08)

## [1.3.7](https://github.com/sprucelabsai/spruce-error/compare/v1.3.6...v1.3.7) (2020-07-08)

## [1.3.6](https://github.com/sprucelabsai/spruce-error/compare/v1.3.5...v1.3.6) (2020-07-06)

## [1.3.5](https://github.com/sprucelabsai/spruce-error/compare/v1.3.4...v1.3.5) (2020-07-03)

## [1.3.4](https://github.com/sprucelabsai/spruce-error/compare/v1.3.3...v1.3.4) (2020-07-01)

## [1.3.3](https://github.com/sprucelabsai/spruce-error/compare/v1.3.2...v1.3.3) (2020-06-30)


### Bug Fixes

* tighten test pattern ([243c902](https://github.com/sprucelabsai/spruce-error/commit/243c902))

## [1.3.2](https://github.com/sprucelabsai/spruce-error/compare/v1.3.1...v1.3.2) (2020-06-29)

## [1.3.1](https://github.com/sprucelabsai/spruce-error/compare/v1.3.0...v1.3.1) (2020-06-26)

# [1.3.0](https://github.com/sprucelabsai/spruce-error/compare/v1.2.0...v1.3.0) (2020-05-13)


### Features

* readme update ([568b04c](https://github.com/sprucelabsai/spruce-error/commit/568b04c))

# [1.2.0](https://github.com/sprucelabsai/spruce-error/compare/v1.1.0...v1.2.0) (2020-04-22)


### Features

* seperated out toString and toJson and call one from the other ([3a0a4d8](https://github.com/sprucelabsai/spruce-error/commit/3a0a4d8))

# [1.1.0](https://github.com/sprucelabsai/spruce-error/compare/v1.0.12...v1.1.0) (2020-04-22)


### Features

* errors json stringify on "toString" so they can be imported back ([ee1d98d](https://github.com/sprucelabsai/spruce-error/commit/ee1d98d))

## [1.0.12](https://github.com/sprucelabsai/spruce-error/compare/v1.0.11...v1.0.12) (2020-04-17)

## [1.0.11](https://github.com/sprucelabsai/spruce-error/compare/v1.0.10...v1.0.11) (2020-04-07)

## [1.0.10](https://github.com/sprucelabsai/spruce-error/compare/v1.0.9...v1.0.10) (2020-04-07)

## [1.0.9](https://github.com/sprucelabsai/spruce-error/compare/v1.0.8...v1.0.9) (2020-04-07)

## [1.0.8](https://github.com/sprucelabsai/spruce-error/compare/v1.0.7...v1.0.8) (2020-04-04)

## [1.0.7](https://github.com/sprucelabsai/spruce-error/compare/v1.0.6...v1.0.7) (2020-04-03)

## [1.0.6](https://github.com/sprucelabsai/spruce-error/compare/v1.0.5...v1.0.6) (2020-04-03)

## [1.0.5](https://github.com/sprucelabsai/spruce-error/compare/v1.0.4...v1.0.5) (2020-04-03)

## [1.0.4](https://github.com/sprucelabsai/spruce-error/compare/v1.0.3...v1.0.4) (2020-04-03)

## [1.0.3](https://github.com/sprucelabsai/spruce-error/compare/v1.0.2...v1.0.3) (2020-03-30)

## [1.0.2](https://github.com/sprucelabsai/spruce-error/compare/v1.0.1...v1.0.2) (2020-03-30)

## [1.0.1](https://github.com/sprucelabsai/spruce-error/compare/v1.0.0...v1.0.1) (2020-03-26)

# 1.0.0 (2020-03-26)
