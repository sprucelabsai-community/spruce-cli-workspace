module.exports = {
	extends: 'spruce',
}
